# Toyota Auth0 ACUL React App

React application implementing Auth0 ACUL (Custom Universal Login) with Toyota-branded login screens.

## Prerequisites

- Node.js 18+ (recommended: LTS version 22.x)
- npm 8+
- nvm (Node Version Manager) recommended

## Setup

1. Set Node version (if using nvm):
```bash
nvm use
```

2. Install dependencies:
```bash
npm install
```

3. Configure Auth0:
   - The app uses `@auth0/auth0-acul-js` which reads configuration from URL parameters
   - Ensure your Auth0 tenant is configured with the ACUL screens

4. Start development server:
```bash
npm run dev
```

5. Open browser to the URL shown (typically http://localhost:5173)

**Note**: This app requires proper Auth0 ACUL configuration to function. When accessed directly without Auth0 query parameters, the screen detection will return empty and show a loading state.

## Project Structure

```
src/
├── components/
│   ├── LoginId/          # Email/identifier entry screen
│   └── LoginPassword/    # Password entry screen
├── services/
│   └── deviceTracking.ts # Device ID management
├── styles/
│   └── global.css        # Global styles with Toyota background
├── App.tsx               # Main app with screen routing
└── main.tsx              # Entry point
```

## Features

- **LoginId Screen**: Email input with social login options (Apple, Google, Facebook)
- **LoginPassword Screen**: Password entry with error handling
- **Device Tracking**: UUID-based device identification stored in localStorage
- **Responsive Design**: Mobile-optimized layouts
- **Toyota Branding**: Toyota red (#eb0a1e) with car background image

## Auth0 Integration

The app uses Auth0 ACUL screen providers:
- `LoginId` from `@auth0/auth0-acul-js` for identifier screen
- `LoginPassword` from `@auth0/auth0-acul-js` for password screen
- `getCurrentScreen()` for screen detection and routing

## Build

```bash
npm run build
```

Output will be in the `dist/` directory.
