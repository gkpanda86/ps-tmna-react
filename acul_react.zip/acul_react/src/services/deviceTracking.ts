const DEVICE_ID_KEY = 'device-id';

export const getDeviceId = (): string => {
  let deviceId = localStorage.getItem(DEVICE_ID_KEY);

  if (!deviceId) {
    deviceId = crypto.randomUUID();
    localStorage.setItem(DEVICE_ID_KEY, deviceId);
  }

  return deviceId;
};

export const setDeviceId = (id: string): void => {
  localStorage.setItem(DEVICE_ID_KEY, id);
};
