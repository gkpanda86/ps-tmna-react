import { useState, useEffect, FormEvent } from "react";
import { LoginPassword as ScreenProvider } from "@auth0/auth0-acul-js";
import { getDeviceId } from "../../services/deviceTracking";
import "./LoginPassword.css";

const LoginPassword = () => {
  const [screenProvider, setScreenProvider] = useState<ScreenProvider | null>(
    null,
  );
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [deviceId] = useState(() => getDeviceId());

  useEffect(() => {
    try {
      const provider = new ScreenProvider();
      setScreenProvider(provider);
      console.log("LoginPassword screen provider:", provider);
      console.log("Device ID:", deviceId);

      if (provider.transaction?.hasErrors) {
        setHasError(true);
      }
    } catch (error) {
      console.error(
        "Failed to initialize LoginPassword screen provider:",
        error,
      );
    }
  }, [deviceId]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!screenProvider) return;

    setIsLoading(true);
    setHasError(false);

    const username = screenProvider.screen?.data?.username || "";

    try {
      await screenProvider.login({
        username,
        password,
        "ulp-identifier": username,
        "ulp-device-id": deviceId,
      });
    } catch (error) {
      console.error("Login error:", error);
      setHasError(true);
      setIsLoading(false);
    }
  };

  const handleEditUsername = () => {
    if (!screenProvider) return;
    const editLink = screenProvider.screen?.links?.edit_identifier;
    if (editLink) {
      window.location.href = editLink;
    }
  };

  const handleForgotPassword = () => {
    if (!screenProvider) return;
    const resetLink = screenProvider.screen?.links?.reset_password;
    if (resetLink) {
      window.location.href = resetLink;
    }
  };

  const handleSwitchToOTP = () => {
    if (!screenProvider) return;

    // Get the state from the ACUL SDK
    const state = screenProvider.transaction?.state || "";

    // Create a form element dynamically
    const form = document.createElement("form");
    form.method = "POST";
    form.action = window.location.href;

    // Add state parameter
    const stateInput = document.createElement("input");
    stateInput.type = "hidden";
    stateInput.name = "state";
    stateInput.value = state || "";
    form.appendChild(stateInput);

    // Add action parameter
    const actionInput = document.createElement("input");
    actionInput.type = "hidden";
    actionInput.name = "action";
    actionInput.value = "switch-to-otp-auth";
    form.appendChild(actionInput);

    // Append to body and submit
    document.body.appendChild(form);
    form.submit();
  };

  if (!screenProvider) {
    return (
      <div className="login-password-container">
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const username = screenProvider.screen?.data?.username || "";
  const title = screenProvider.screen?.texts?.title || "Enter your password";
  const logoUrl = screenProvider.client?.logoUrl;
  const editLink = screenProvider.screen?.links?.edit_identifier;

  return (
    <div className="login-password-container">
      <div className="logo">
        <div className="logo-box">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo"
              style={{ width: "24px", height: "24px" }}
            />
          ) : (
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              T
            </span>
          )}
        </div>
        <span className="logo-text">TOYOTA</span>
      </div>

      <h1>{title}</h1>
      <p className="subtitle">
        Welcome back! Please enter your password to continue.
      </p>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">
            Email <span className="required-asterisk">*</span>
          </label>
          <input
            type="email"
            value={username}
            disabled
            className="email-input"
          />
          {editLink && (
            <button
              type="button"
              className="edit-link"
              onClick={handleEditUsername}
            >
              Edit
            </button>
          )}
        </div>

        <div className="form-group">
          <label className="form-label">
            Password <span className="required-asterisk">*</span>
          </label>
          <div className="input-wrapper">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
              className={hasError ? "error" : ""}
              autoFocus
            />
            <button
              type="button"
              className="password-toggle"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? "👁️" : "👁️‍🗨️"}
            </button>
          </div>
          {hasError && (
            <div className="error-message">
              Wrong email or password. Please try again.
            </div>
          )}
        </div>

        <p className="required-note">
          <span className="required-asterisk">*</span> Required fields
        </p>

        <button
          type="submit"
          className="sign-in-button"
          disabled={!password || isLoading}
        >
          Sign In
        </button>

        <button
          type="button"
          className="otp-switch-button"
          onClick={handleSwitchToOTP}
          disabled={isLoading}
        >
          Continue with code instead
        </button>
      </form>

      <p className="trouble-text">Having trouble signing in?</p>

      <div className="footer-links">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
          }}
        >
          Contact Support
        </a>
        <a href="#" onClick={handleForgotPassword}>
          Forgot Password
        </a>
      </div>
    </div>
  );
};

export default LoginPassword;
