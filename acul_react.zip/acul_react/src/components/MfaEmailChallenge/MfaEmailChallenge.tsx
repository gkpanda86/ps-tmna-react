import { useState, useEffect, FormEvent } from "react";
import { MfaEmailChallenge as ScreenProvider } from "@auth0/auth0-acul-js";
import "./MfaEmailChallenge.css";

const MfaEmailChallenge = () => {
  const [screenProvider, setScreenProvider] = useState<ScreenProvider | null>(
    null,
  );
  const [verificationCode, setVerificationCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    try {
      const provider = new ScreenProvider();
      setScreenProvider(provider);
      console.log("MfaEmailChallenge screen provider:", provider);

      if (provider.transaction?.hasErrors) {
        setHasError(true);
      }
    } catch (error) {
      console.error(
        "Failed to initialize MfaEmailChallenge screen provider:",
        error,
      );
    }
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!screenProvider) return;

    setIsLoading(true);
    setHasError(false);

    try {
      // @ts-ignore - Method might be available at runtime
      await screenProvider.continue({
        code: verificationCode,
        rememberDevice: false,
      });
    } catch (error) {
      console.error("MFA verification error:", error);
      setHasError(true);
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
    if (!screenProvider) return;

    try {
      // @ts-ignore - Method might be available at runtime
      await screenProvider.resendCode();
      console.log("MFA code resent");
    } catch (error) {
      console.error("Resend error:", error);
    }
  };

  if (!screenProvider) {
    return (
      <div className="mfa-email-challenge-container">
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const email = screenProvider.screen?.data?.email || "";
  const title =
    screenProvider.screen?.texts?.title || "Multi-Factor Authentication";
  const description =
    screenProvider.screen?.texts?.description ||
    "Enter the verification code sent to your email";
  const logoUrl = screenProvider.client?.logoUrl;

  return (
    <div className="mfa-email-challenge-container">
      <div className="logo">
        <div className="logo-box">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo"
              style={{ width: "24px", height: "24px" }}
            />
          ) : (
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              T
            </span>
          )}
        </div>
        <span className="logo-text">TOYOTA</span>
      </div>

      <h1>{title}</h1>
      <p className="subtitle">{description}</p>

      {email && (
        <div className="email-display">
          <p className="email-text">
            Verification code sent to: <strong>{email}</strong>
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">
            Verification Code <span className="required-asterisk">*</span>
          </label>
          <input
            type="text"
            placeholder="Enter 6-digit code"
            value={verificationCode}
            onChange={(e) => setVerificationCode(e.target.value)}
            disabled={isLoading}
            className={hasError ? "error" : ""}
            maxLength={6}
            autoFocus
          />
          {hasError && (
            <div className="error-message">
              Invalid verification code. Please try again.
            </div>
          )}
        </div>

        <button
          type="submit"
          className="verify-button"
          disabled={!verificationCode || isLoading}
        >
          {isLoading ? "Verifying..." : "Verify"}
        </button>
      </form>

      <div className="resend-section">
        <p className="resend-text">Didn't receive the code?</p>
        <button
          type="button"
          className="resend-button"
          onClick={handleResend}
          disabled={isLoading}
        >
          Resend Code
        </button>
      </div>

      <div className="footer-text">
        Check your spam folder if you don't see the email. The code will expire
        in 10 minutes.
      </div>
    </div>
  );
};

export default MfaEmailChallenge;
