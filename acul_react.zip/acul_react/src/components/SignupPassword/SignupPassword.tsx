import { useState, useEffect, FormEvent } from "react";
import { SignupPassword as ScreenProvider } from "@auth0/auth0-acul-js";
import { getDeviceId } from "../../services/deviceTracking";
import "./SignupPassword.css";

const SignupPassword = () => {
  const [screenProvider, setScreenProvider] = useState<ScreenProvider | null>(
    null,
  );
  const [password, setPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [accountType, setAccountType] = useState<"individual" | "business">("individual");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [deviceId] = useState(() => getDeviceId());

  useEffect(() => {
    try {
      const provider = new ScreenProvider();
      setScreenProvider(provider);
      console.log("SignupPassword screen provider:", provider);
      console.log("Device ID:", deviceId);

      if (provider.transaction?.hasErrors) {
        setHasError(true);
        setErrorMessage(provider.transaction.errors?.[0]?.message || "");
      }
    } catch (error) {
      console.error(
        "Failed to initialize SignupPassword screen provider:",
        error,
      );
    }
  }, [deviceId]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!screenProvider) return;

    setIsLoading(true);
    setHasError(false);
    setErrorMessage("");

    const email = screenProvider.screen?.data?.email || "";
    const phone = screenProvider.screen?.data?.phoneNumber || "";

    try {
      const signupData: any = {
        email: email,
        phone_number: phone,
        password: password,
        "ulp-device-id": deviceId,
        "ulp-account-type": accountType,
      };

      if (accountType === "individual") {
        signupData["ulp-given-name"] = firstName;
        signupData["ulp-family-name"] = lastName;
      } else {
        signupData["ulp-business-name"] = businessName;
      }

      await screenProvider.signup(signupData);
    } catch (error) {
      console.error("Signup error:", error);
      const message =
        error instanceof Error
          ? error.message
          : (error as any)?.error_description ||
            (error as any)?.description ||
            "Failed to create account. Please try again.";
      setErrorMessage(message);
      setHasError(true);
      setIsLoading(false);
    }
  };

  const handleEditDetails = () => {
    if (!screenProvider) return;
    const editLink = screenProvider.screen?.links?.edit_identifier;
    if (editLink) {
      window.location.href = editLink;
    }
  };

  if (!screenProvider) {
    return (
      <div className="signup-password-container">
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const email = screenProvider.screen?.data?.email || "";
  const phone = screenProvider.screen?.data?.phoneNumber || "";
  const title = screenProvider.screen?.texts?.title || "Create Your Password";
  const logoUrl = screenProvider.client?.logoUrl;
  const editLink = screenProvider.screen?.links?.edit_identifier;

  return (
    <div className="signup-password-container">
      <div className="logo">
        <div className="logo-box">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo"
              style={{ width: "24px", height: "24px" }}
            />
          ) : (
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              T
            </span>
          )}
        </div>
        <span className="logo-text">TOYOTA</span>
      </div>

      <h1>{title}</h1>
      <p className="subtitle">
        Almost there! Please provide your name and create a password.
      </p>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">
            Account Type <span className="required-asterisk">*</span>
          </label>
          <div className="radio-group">
            <label className="radio-label">
              <input
                type="radio"
                name="accountType"
                value="individual"
                checked={accountType === "individual"}
                onChange={(e) => setAccountType(e.target.value as "individual" | "business")}
                disabled={isLoading}
              />
              <span>Individual</span>
            </label>
            <label className="radio-label">
              <input
                type="radio"
                name="accountType"
                value="business"
                checked={accountType === "business"}
                onChange={(e) => setAccountType(e.target.value as "individual" | "business")}
                disabled={isLoading}
              />
              <span>Business</span>
            </label>
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">
            Email <span className="required-asterisk">*</span>
          </label>
          <input type="email" value={email} disabled className="email-input" />
        </div>

        <div className="form-group">
          <label className="form-label">
            Phone Number <span className="required-asterisk">*</span>
          </label>
          <input type="tel" value={phone} className="phone-input" disabled />
          {editLink && (
            <button
              type="button"
              className="edit-link"
              onClick={handleEditDetails}
            >
              Edit
            </button>
          )}
        </div>

        {accountType === "individual" ? (
          <>
            <div className="form-group">
              <label className="form-label">
                First Name <span className="required-asterisk">*</span>
              </label>
              <input
                type="text"
                placeholder="First Name"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                disabled={isLoading}
                autoFocus
              />
            </div>

            <div className="form-group">
              <label className="form-label">
                Last Name <span className="required-asterisk">*</span>
              </label>
              <input
                type="text"
                placeholder="Last Name"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                disabled={isLoading}
              />
            </div>
          </>
        ) : (
          <div className="form-group">
            <label className="form-label">
              Business Name <span className="required-asterisk">*</span>
            </label>
            <input
              type="text"
              placeholder="Business Name"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              disabled={isLoading}
              autoFocus
            />
          </div>
        )}

        <div className="form-group">
          <label className="form-label">
            Password <span className="required-asterisk">*</span>
          </label>
          <div className="input-wrapper">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
              className={hasError ? "error" : ""}
              placeholder="Enter a strong password"
            />
            <button
              type="button"
              className="password-toggle"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? "👁️" : "👁️‍🗨️"}
            </button>
          </div>
          {hasError && errorMessage && (
            <div className="error-message">{errorMessage}</div>
          )}
          <p className="password-hint">
            Password must be at least 8 characters long
          </p>
        </div>

        <p className="required-note">
          <span className="required-asterisk">*</span> Required fields
        </p>

        <p className="terms-agreement">
          By clicking "Create Account", you agree to Toyota's Terms of Service
          and Privacy Policy.
        </p>

        <button
          type="submit"
          className="create-account-button"
          disabled={
            isLoading ||
            !password ||
            (accountType === "individual" && (!firstName || !lastName)) ||
            (accountType === "business" && !businessName)
          }
        >
          Create Account
        </button>
      </form>

      <div className="footer-text">
        By creating an account, you agree to Toyota's Terms of Service and
        Privacy Policy.
      </div>
    </div>
  );
};

export default SignupPassword;
