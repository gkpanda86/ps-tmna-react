import { useState, useEffect, FormEvent } from "react";
import { ResetPasswordRequest as ScreenProvider } from "@auth0/auth0-acul-js";
import "./ResetPasswordRequest.css";

const ResetPasswordRequest = () => {
  const [screenProvider, setScreenProvider] = useState<ScreenProvider | null>(
    null,
  );
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    try {
      const provider = new ScreenProvider();
      setScreenProvider(provider);
      console.log("ResetPasswordRequest screen provider:", provider);

      // Pre-fill email if available
      const username = provider.screen?.data?.username;
      if (username) {
        setEmail(username);
      }

      if (provider.transaction?.hasErrors) {
        setHasError(true);
      }
    } catch (error) {
      console.error(
        "Failed to initialize ResetPasswordRequest screen provider:",
        error,
      );
    }
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!screenProvider) return;

    setIsLoading(true);
    setHasError(false);

    try {
      // @ts-ignore - Method might be available at runtime
      await screenProvider.resetPassword({ username: email });
    } catch (error) {
      console.error("Password reset request error:", error);
      setHasError(true);
      setIsLoading(false);
    }
  };

  const handleBackToLogin = () => {
    if (!screenProvider) return;
    const loginLink = screenProvider.screen?.links?.login;
    if (loginLink) {
      window.location.href = loginLink;
    }
  };

  if (!screenProvider) {
    return (
      <div className="reset-password-request-container">
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const title = screenProvider.screen?.texts?.title || "Reset Your Password";
  const description =
    screenProvider.screen?.texts?.description ||
    "Enter your email address and we'll send you a link to reset your password";
  const emailPlaceholder =
    screenProvider.screen?.texts?.emailPlaceholder || "Email";
  const buttonText =
    screenProvider.screen?.texts?.buttonText || "Send Reset Link";
  const logoUrl = screenProvider.client?.logoUrl;

  return (
    <div className="reset-password-request-container">
      <div className="logo">
        <div className="logo-box">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo"
              style={{ width: "24px", height: "24px" }}
            />
          ) : (
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              T
            </span>
          )}
        </div>
        <span className="logo-text">TOYOTA</span>
      </div>

      <h1>{title}</h1>
      <p className="subtitle">{description}</p>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">
            Email <span className="required-asterisk">*</span>
          </label>
          <input
            type="email"
            placeholder={emailPlaceholder}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={isLoading}
            className={hasError ? "error" : ""}
            autoFocus
          />
          {hasError && (
            <div className="error-message">
              Unable to send reset link. Please check your email and try again.
            </div>
          )}
        </div>

        <button
          type="submit"
          className="submit-button"
          disabled={!email || isLoading}
        >
          {isLoading ? "Sending..." : buttonText}
        </button>
      </form>

      <div className="back-to-login-container">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            handleBackToLogin();
          }}
          className="back-to-login-link"
        >
          Back to Sign In
        </a>
      </div>

      <div className="footer-text">
        Check your spam folder if you don't see the email. The reset link will
        expire in 24 hours.
      </div>
    </div>
  );
};

export default ResetPasswordRequest;
