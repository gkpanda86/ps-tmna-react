import { useState, useEffect, FormEvent } from "react";
import { PhoneIdentifierChallenge as ScreenProvider } from "@auth0/auth0-acul-js";
import "./PhoneIdentifierChallenge.css";

const PhoneIdentifierChallenge = () => {
  const [screenProvider, setScreenProvider] = useState<ScreenProvider | null>(
    null,
  );
  const [verificationCode, setVerificationCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    try {
      const provider = new ScreenProvider();
      setScreenProvider(provider);
      console.log("PhoneIdentifierChallenge screen provider:", provider);

      if (provider.transaction?.hasErrors) {
        setHasError(true);
      }
    } catch (error) {
      console.error(
        "Failed to initialize PhoneIdentifierChallenge screen provider:",
        error,
      );
    }
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!screenProvider) return;

    setIsLoading(true);
    setHasError(false);

    try {
      // @ts-ignore - Method might be available at runtime
      await screenProvider.submitPhoneChallenge({
        code: verificationCode,
      });
    } catch (error) {
      console.error("Verification error:", error);
      setHasError(true);
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
    if (!screenProvider) return;

    try {
      // @ts-ignore - Method might be available at runtime
      await screenProvider.resendCode();
      console.log("Verification code resent");
    } catch (error) {
      console.error("Resend error:", error);
    }
  };

  const handleEdit = () => {
    if (!screenProvider) return;
    const editLink = screenProvider.screen?.links?.edit_identifier;
    if (editLink) {
      window.location.href = editLink;
    }
  };

  const handleSwitchToPassword = () => {
    if (!screenProvider) return;

    // Get the state from the ACUL SDK
    const state = screenProvider.transaction?.state || "";

    // Create a form element dynamically
    const form = document.createElement("form");
    form.method = "POST";
    form.action = window.location.href;

    // Add state parameter
    const stateInput = document.createElement("input");
    stateInput.type = "hidden";
    stateInput.name = "state";
    stateInput.value = state;
    form.appendChild(stateInput);

    // Add action parameter
    const actionInput = document.createElement("input");
    actionInput.type = "hidden";
    actionInput.name = "action";
    actionInput.value = "switch-to-password-auth";
    form.appendChild(actionInput);

    // Append to body and submit
    document.body.appendChild(form);
    form.submit();
  };

  if (!screenProvider) {
    return (
      <div className="phone-challenge-container">
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const showSwitchToPassword =
    (screenProvider.screen?.data as any)?.show_switch_to_password_button ===
    true;

  const phone = showSwitchToPassword
    ? (screenProvider.screen?.data as any)?.username
    : screenProvider.screen?.data?.phone;
  const title = showSwitchToPassword
    ? screenProvider.screen?.texts?.titleWhenPhoneNumberFieldShown
    : screenProvider.screen?.texts?.title;
  const description = showSwitchToPassword
    ? screenProvider.screen?.texts?.descriptionWhenPhoneNumberFieldShown
    : "Enter the verification code sent to your phone";
  const logoUrl = screenProvider.client?.logoUrl;
  const editLink = screenProvider.screen?.links?.edit_identifier;

  return (
    <div className="phone-challenge-container">
      <div className="logo">
        <div className="logo-box">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo"
              style={{ width: "24px", height: "24px" }}
            />
          ) : (
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              T
            </span>
          )}
        </div>
        <span className="logo-text">TOYOTA</span>
      </div>

      <h1>{title}</h1>
      <p className="subtitle">{description}</p>

      {phone && !showSwitchToPassword && (
        <div className="phone-display">
          <p className="phone-text">
            Verification code sent to: <strong>{phone}</strong>
          </p>
          {editLink && (
            <button
              type="button"
              className="edit-phone-link"
              onClick={handleEdit}
            >
              Edit Phone
            </button>
          )}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        {showSwitchToPassword && (
          <div className="form-group">
            <label className="form-label">
              Phone Number <span className="required-asterisk">*</span>
            </label>
            <input type="text" value={phone} disabled className="phone-input" />
          </div>
        )}

        <div className="form-group">
          <label className="form-label">
            Verification Code <span className="required-asterisk">*</span>
          </label>
          <input
            type="text"
            placeholder="Enter 6-digit code"
            value={verificationCode}
            onChange={(e) => setVerificationCode(e.target.value)}
            disabled={isLoading}
            className={hasError ? "error" : ""}
            maxLength={6}
            autoFocus
          />
          {hasError && (
            <div className="error-message">
              Invalid verification code. Please try again.
            </div>
          )}
        </div>

        <button
          type="submit"
          className="verify-button"
          disabled={!verificationCode || isLoading}
        >
          {showSwitchToPassword ? "Continue" : "Verify Phone"}
        </button>

        {showSwitchToPassword && (
          <button
            type="button"
            className="password-switch-button"
            onClick={handleSwitchToPassword}
            disabled={isLoading}
          >
            Continue with a password
          </button>
        )}
      </form>

      <div className="resend-section">
        <p className="resend-text">Didn't receive the code?</p>
        <button
          type="button"
          className="resend-button"
          onClick={handleResend}
          disabled={isLoading}
        >
          Resend Code
        </button>
      </div>

      <div className="footer-text">
        Check your messages if you don't see the SMS. The code will expire in 10
        minutes.
      </div>
    </div>
  );
};

export default PhoneIdentifierChallenge;
