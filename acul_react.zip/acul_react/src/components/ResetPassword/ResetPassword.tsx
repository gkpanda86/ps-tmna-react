import { useState, useEffect, FormEvent } from "react";
import { ResetPassword as ScreenProvider } from "@auth0/auth0-acul-js";
import "./ResetPassword.css";

const ResetPassword = () => {
  const [screenProvider, setScreenProvider] = useState<ScreenProvider | null>(
    null,
  );
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    try {
      const provider = new ScreenProvider();
      setScreenProvider(provider);
      console.log("ResetPassword screen provider:", provider);

      if (provider.transaction?.hasErrors) {
        setHasError(true);
      }
    } catch (error) {
      console.error(
        "Failed to initialize ResetPassword screen provider:",
        error,
      );
    }
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!screenProvider) return;

    if (password !== confirmPassword) {
      setHasError(true);
      return;
    }

    setIsLoading(true);
    setHasError(false);

    try {
      // @ts-ignore - Method might be available at runtime
      await screenProvider.resetPassword({
        "password-reset": password,
        "re-enter-password": confirmPassword,
      });
    } catch (error) {
      console.error("Password reset error:", error);
      setHasError(true);
      setIsLoading(false);
    }
  };

  if (!screenProvider) {
    return (
      <div className="reset-password-container">
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const email = screenProvider.screen?.data?.username || "";
  const title = screenProvider.screen?.texts?.title || "Reset Your Password";
  const description =
    screenProvider.screen?.texts?.description ||
    "Enter your new password below";
  const passwordPlaceholder =
    screenProvider.screen?.texts?.passwordPlaceholder || "New Password";
  const buttonText =
    screenProvider.screen?.texts?.buttonText || "Reset Password";
  const logoUrl = screenProvider.client?.logoUrl;

  return (
    <div className="reset-password-container">
      <div className="logo">
        <div className="logo-box">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo"
              style={{ width: "24px", height: "24px" }}
            />
          ) : (
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              T
            </span>
          )}
        </div>
        <span className="logo-text">TOYOTA</span>
      </div>

      <h1>{title}</h1>
      <p className="subtitle">{description}</p>

      {email && (
        <div className="email-display">
          <p className="email-text">
            Account: <strong>{email}</strong>
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">
            New Password <span className="required-asterisk">*</span>
          </label>
          <input
            type="password"
            placeholder={passwordPlaceholder}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            disabled={isLoading}
            className={hasError ? "error" : ""}
            autoFocus
          />
        </div>

        <div className="form-group">
          <label className="form-label">
            Confirm Password <span className="required-asterisk">*</span>
          </label>
          <input
            type="password"
            placeholder="Confirm New Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            disabled={isLoading}
            className={hasError ? "error" : ""}
          />
          {hasError && (
            <div className="error-message">
              {password !== confirmPassword
                ? "Passwords do not match. Please try again."
                : "Unable to reset password. Please try again or request a new reset link."}
            </div>
          )}
        </div>

        <button
          type="submit"
          className="submit-button"
          disabled={!password || !confirmPassword || isLoading}
        >
          {isLoading ? "Resetting..." : buttonText}
        </button>
      </form>

      <div className="footer-text">
        Your new password must be at least 8 characters long and contain a mix
        of letters, numbers, and symbols.
      </div>
    </div>
  );
};

export default ResetPassword;
