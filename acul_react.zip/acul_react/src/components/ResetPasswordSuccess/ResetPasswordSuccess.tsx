import { useState, useEffect } from "react";
import { ResetPasswordSuccess as ScreenProvider } from "@auth0/auth0-acul-js";
import "./ResetPasswordSuccess.css";

const ResetPasswordSuccess = () => {
  const [screenProvider, setScreenProvider] = useState<ScreenProvider | null>(
    null,
  );

  useEffect(() => {
    try {
      const provider = new ScreenProvider();
      setScreenProvider(provider);
      console.log("ResetPasswordSuccess screen provider:", provider);
    } catch (error) {
      console.error(
        "Failed to initialize ResetPasswordSuccess screen provider:",
        error,
      );
    }
  }, []);

  const handleBackToLogin = () => {
    if (!screenProvider) return;
    const loginLink = screenProvider.screen?.links?.back_to_app;
    if (loginLink) {
      window.location.href = loginLink;
    }
  };

  if (!screenProvider) {
    return (
      <div className="reset-password-success-container">
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const title =
    screenProvider.screen?.texts?.title || "Password Reset Successful";
  const description =
    screenProvider.screen?.texts?.description ||
    "Your password has been reset successfully. You can now sign in with your new password.";
  const buttonText =
    screenProvider.screen?.texts?.buttonText || "Back to Sign In";
  const logoUrl = screenProvider.client?.logoUrl;

  return (
    <div className="reset-password-success-container">
      <div className="logo">
        <div className="logo-box">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo"
              style={{ width: "24px", height: "24px" }}
            />
          ) : (
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              T
            </span>
          )}
        </div>
        <span className="logo-text">TOYOTA</span>
      </div>

      <div className="success-icon">✓</div>

      <h1>{title}</h1>
      <p className="description">{description}</p>

      <button
        type="button"
        className="login-button"
        onClick={handleBackToLogin}
      >
        {buttonText}
      </button>
    </div>
  );
};

export default ResetPasswordSuccess;
