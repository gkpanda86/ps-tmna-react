import { useState, useEffect, FormEvent } from "react";
import { SignupId as ScreenProvider } from "@auth0/auth0-acul-js";
import "./SignupId.css";

const SignupId = () => {
  const [screenProvider, setScreenProvider] = useState<ScreenProvider | null>(
    null,
  );
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [countryCode, setCountryCode] = useState("+1");
  const [isLoading, setIsLoading] = useState(false);

  // Common country codes with flags
  const countryCodes = [
    { code: "+1", country: "US/CA", flag: "🇺🇸" },
    { code: "+44", country: "UK", flag: "🇬🇧" },
    { code: "+91", country: "IN", flag: "🇮🇳" },
    { code: "+81", country: "JP", flag: "🇯🇵" },
    { code: "+86", country: "CN", flag: "🇨🇳" },
    { code: "+49", country: "DE", flag: "🇩🇪" },
    { code: "+33", country: "FR", flag: "🇫🇷" },
    { code: "+39", country: "IT", flag: "🇮🇹" },
    { code: "+61", country: "AU", flag: "🇦🇺" },
    { code: "+52", country: "MX", flag: "🇲🇽" },
  ];

  useEffect(() => {
    try {
      const provider = new ScreenProvider();
      setScreenProvider(provider);
      console.log("SignupId screen provider:", provider);
    } catch (error) {
      console.error("Failed to initialize SignupId screen provider:", error);
    }
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!screenProvider) return;

    setIsLoading(true);

    // Concatenate country code with phone number
    const fullPhoneNumber = `${countryCode}${phone}`;

    try {
      await screenProvider.signup({
        email: email,
        phone: fullPhoneNumber,
      });
    } catch (error) {
      console.error("Signup error:", error);
      setIsLoading(false);
    }
  };

  const handleSocialSignup = async (connection: string) => {
    if (!screenProvider) return;

    try {
      await screenProvider.federatedSignup({ connection });
    } catch (error) {
      console.error("Social signup error:", error);
    }
  };

  if (!screenProvider) {
    return (
      <div className="signup-id-container">
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const title = screenProvider.screen?.texts?.title || "Create Your Account";
  const emailPlaceholder =
    screenProvider.screen?.texts?.emailPlaceholder || "Email";
  const buttonText = screenProvider.screen?.texts?.buttonText || "Continue";
  const logoUrl = screenProvider.client?.logoUrl;
  const loginLink = screenProvider.screen?.links?.login;

  return (
    <div className="signup-id-container">
      <div className="logo">
        <div className="logo-box">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo"
              style={{ width: "24px", height: "24px" }}
            />
          ) : (
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              T
            </span>
          )}
        </div>
        <span className="logo-text">TOYOTA</span>
      </div>

      <div className="content">
        <div className="left-section">
          <h1>{title}</h1>
          <p className="section-title">
            Enter your email and phone number to get started
          </p>

          <form onSubmit={handleSubmit}>
            <div className="input-group">
              <label className="input-label">
                Email <span className="required-asterisk">*</span>
              </label>
              <input
                type="email"
                placeholder={emailPlaceholder}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
                autoFocus
              />
            </div>

            <div className="input-group">
              <label className="input-label">
                Phone Number <span className="required-asterisk">*</span>
              </label>
              <div className="phone-input-container">
                <select
                  className="country-code-select"
                  value={countryCode}
                  onChange={(e) => setCountryCode(e.target.value)}
                  disabled={isLoading}
                >
                  {countryCodes.map((country) => (
                    <option key={country.code} value={country.code}>
                      {country.flag} {country.code}
                    </option>
                  ))}
                </select>
                <input
                  type="tel"
                  placeholder="Phone Number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  disabled={isLoading}
                  className="phone-number-input"
                />
              </div>
            </div>

            <div className="button-group">
              <button
                type="submit"
                className={email ? "btn-outline" : "btn-disabled"}
                disabled={!email || isLoading}
              >
                {buttonText}
              </button>
            </div>
          </form>

          {loginLink && (
            <div className="login-link-container">
              <p className="login-text">
                Already have an account?{" "}
                <a href={loginLink} className="login-link">
                  Sign In
                </a>
              </p>
            </div>
          )}

          <div className="footer-text">
            By continuing, you agree to Toyota's Terms of Service and Privacy
            Policy.
          </div>
        </div>

        <div className="divider">
          <span className="divider-text">OR</span>
        </div>

        <div className="right-section">
          <p className="section-title">Sign up with</p>

          <button
            className="sso-button"
            onClick={() => handleSocialSignup("apple")}
          >
            <img
              src="https://cdn.auth0.com/marketplace/catalog/content/assets/creators/apple/apple-avatar.png"
              alt="Apple"
              className="sso-icon"
            />
            <span>Continue with Apple</span>
          </button>

          <button
            className="sso-button"
            onClick={() => handleSocialSignup("google-oauth2")}
          >
            <img
              src="https://cdn.auth0.com/marketplace/catalog/content/assets/creators/google/google-avatar.png"
              alt="Google"
              className="sso-icon"
            />
            <span>Continue with Google</span>
          </button>

          <button
            className="sso-button"
            onClick={() => handleSocialSignup("facebook")}
          >
            <img
              src="https://cdn.auth0.com/marketplace/catalog/content/assets/creators/facebook/facebook-avatar.png"
              alt="Facebook"
              className="sso-icon"
            />
            <span>Continue with Facebook</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SignupId;
