import { useState, useEffect, FormEvent } from "react";
import { EmailIdentifierChallenge as ScreenProvider } from "@auth0/auth0-acul-js";
import "./EmailIdentifierChallenge.css";

const EmailIdentifierChallenge = () => {
  const [screenProvider, setScreenProvider] = useState<ScreenProvider | null>(
    null,
  );
  const [verificationCode, setVerificationCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    try {
      const provider = new ScreenProvider();
      setScreenProvider(provider);
      console.log("EmailIdentifierChallenge screen provider:", provider);

      if (provider.transaction?.hasErrors) {
        setHasError(true);
      }
    } catch (error) {
      console.error(
        "Failed to initialize EmailIdentifierChallenge screen provider:",
        error,
      );
    }
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!screenProvider) return;

    setIsLoading(true);
    setHasError(false);

    try {
      // @ts-ignore - Method might be available at runtime
      await screenProvider.submitEmailChallenge({
        code: verificationCode,
      });
    } catch (error) {
      console.error("Verification error:", error);
      setHasError(true);
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
    if (!screenProvider) return;

    try {
      // @ts-ignore - Method might be available at runtime
      await screenProvider.resendCode();
      console.log("Verification code resent");
    } catch (error) {
      console.error("Resend error:", error);
    }
  };

  const handleEdit = () => {
    if (!screenProvider) return;
    const editLink = screenProvider.screen?.links?.edit_identifier;
    if (editLink) {
      window.location.href = editLink;
    }
  };

  if (!screenProvider) {
    return (
      <div className="email-challenge-container">
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const email = screenProvider.screen?.data?.email || "";
  const title = screenProvider.screen?.texts?.title || "Verify Your Email";
  const description =
    screenProvider.screen?.texts?.description ||
    "Enter the verification code sent to your email";
  const logoUrl = screenProvider.client?.logoUrl;
  const editLink = screenProvider.screen?.links?.edit_identifier;

  return (
    <div className="email-challenge-container">
      <div className="logo">
        <div className="logo-box">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo"
              style={{ width: "24px", height: "24px" }}
            />
          ) : (
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              T
            </span>
          )}
        </div>
        <span className="logo-text">TOYOTA</span>
      </div>

      <h1>{title}</h1>
      <p className="subtitle">{description}</p>

      {email && (
        <div className="email-display">
          <p className="email-text">
            Verification code sent to: <strong>{email}</strong>
          </p>
          {editLink && (
            <button
              type="button"
              className="edit-email-link"
              onClick={handleEdit}
            >
              Edit Email
            </button>
          )}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">
            Verification Code <span className="required-asterisk">*</span>
          </label>
          <input
            type="text"
            placeholder="Enter 6-digit code"
            value={verificationCode}
            onChange={(e) => setVerificationCode(e.target.value)}
            disabled={isLoading}
            className={hasError ? "error" : ""}
            maxLength={6}
            autoFocus
          />
          {hasError && (
            <div className="error-message">
              Invalid verification code. Please try again.
            </div>
          )}
        </div>

        <button
          type="submit"
          className="verify-button"
          disabled={!verificationCode || isLoading}
        >
          {isLoading ? "Verifying..." : "Verify Email"}
        </button>
      </form>

      <div className="resend-section">
        <p className="resend-text">Didn't receive the code?</p>
        <button
          type="button"
          className="resend-button"
          onClick={handleResend}
          disabled={isLoading}
        >
          Resend Code
        </button>
      </div>

      <div className="footer-text">
        Check your spam folder if you don't see the email. The code will expire
        in 10 minutes.
      </div>
    </div>
  );
};

export default EmailIdentifierChallenge;
