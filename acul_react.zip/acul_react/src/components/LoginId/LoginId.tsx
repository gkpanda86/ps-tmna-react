import { useState, useEffect, FormEvent } from "react";
import { LoginId as ScreenProvider } from "@auth0/auth0-acul-js";
import "./LoginId.css";

const LoginId = () => {
  const [screenProvider, setScreenProvider] = useState<ScreenProvider | null>(
    null,
  );
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    try {
      const provider = new ScreenProvider();
      setScreenProvider(provider);
      console.log("LoginId screen provider:", provider);
    } catch (error) {
      console.error("Failed to initialize LoginId screen provider:", error);
    }
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!screenProvider) return;

    setIsLoading(true);

    try {
      await screenProvider.login({ username: email });
    } catch (error) {
      console.error("Login error:", error);
      setIsLoading(false);
    }
  };

  const onCreateAccount = () => {
    if (!screenProvider) return;
    const signupLink = screenProvider.screen?.links?.signup;
    if (signupLink) {
      window.location.href = signupLink;
    }
  };
  const handleSocialLogin = async (connection: string) => {
    if (!screenProvider) return;

    try {
      await screenProvider.federatedLogin({ connection });
    } catch (error) {
      console.error("Social login error:", error);
    }
  };

  if (!screenProvider) {
    return (
      <div className="login-id-container">
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const title = screenProvider.screen?.texts?.title || "Sign In";
  const emailPlaceholder =
    screenProvider.screen?.texts?.emailPlaceholder || "Email";
  const buttonText = screenProvider.screen?.texts?.buttonText || "Continue";
  const logoUrl = screenProvider.client?.logoUrl;

  return (
    <div className="login-id-container">
      <div className="logo">
        <div className="logo-box">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo"
              style={{ width: "24px", height: "24px" }}
            />
          ) : (
            <span
              style={{ color: "white", fontSize: "24px", fontWeight: "bold" }}
            >
              T
            </span>
          )}
        </div>
        <span className="logo-text">TOYOTA</span>
      </div>

      <div className="content">
        <div className="left-section">
          <h1>{title}</h1>
          <p className="section-title">Enter your email or phone to sign in</p>

          <form onSubmit={handleSubmit}>
            <div className="input-group">
              <input
                type="text"
                placeholder={emailPlaceholder}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
                autoFocus
              />
            </div>

            <div className="button-group">
              <button
                type="submit"
                className={email ? "btn-outline" : "btn-disabled"}
                disabled={!email || isLoading}
              >
                {buttonText}
              </button>
            </div>
          </form>

          <div className="signup-link-container">
            <p className="signup-text">
              Do not have an Account?{" "}
              <a href="#" onClick={(e) => { e.preventDefault(); onCreateAccount(); }} className="signup-link">
                Sign up
              </a>
            </p>
          </div>

          <div className="footer-text">
            By continuing, you agree to Toyota's Terms of Service and Privacy
            Policy.
          </div>
        </div>

        <div className="divider">
          <span className="divider-text">OR</span>
        </div>

        <div className="right-section">
          <p className="section-title">Sign in with</p>

          <button
            className="sso-button"
            onClick={() => handleSocialLogin("apple")}
          >
            <img
              src="https://cdn.auth0.com/marketplace/catalog/content/assets/creators/apple/apple-avatar.png"
              alt="Apple"
              className="sso-icon"
            />
            <span>Continue with Apple</span>
          </button>

          <button
            className="sso-button"
            onClick={() => handleSocialLogin("google-oauth2")}
          >
            <img
              src="https://cdn.auth0.com/marketplace/catalog/content/assets/creators/google/google-avatar.png"
              alt="Google"
              className="sso-icon"
            />
            <span>Continue with Google</span>
          </button>

          <button
            className="sso-button"
            onClick={() => handleSocialLogin("facebook")}
          >
            <img
              src="https://cdn.auth0.com/marketplace/catalog/content/assets/creators/facebook/facebook-avatar.png"
              alt="Facebook"
              className="sso-icon"
            />
            <span>Continue with Facebook</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginId;
