import { useState, useEffect } from 'react';
import { getCurrentScreen } from '@auth0/auth0-acul-js';
import LoginId from './components/LoginId/LoginId';
import LoginPassword from './components/LoginPassword/LoginPassword';
import SignupId from './components/SignupId/SignupId';
import SignupPassword from './components/SignupPassword/SignupPassword';
import EmailIdentifierChallenge from './components/EmailIdentifierChallenge/EmailIdentifierChallenge';
import PhoneIdentifierChallenge from './components/PhoneIdentifierChallenge/PhoneIdentifierChallenge';
import MfaEmailChallenge from './components/MfaEmailChallenge/MfaEmailChallenge';
import ResetPasswordRequest from './components/ResetPasswordRequest/ResetPasswordRequest';
import ResetPassword from './components/ResetPassword/ResetPassword';
import ResetPasswordSuccess from './components/ResetPasswordSuccess/ResetPasswordSuccess';
import './App.css';

function App() {
  const [screenName, setScreenName] = useState<string | null>(() => getCurrentScreen());

  useEffect(() => {
    console.log('Current screen:', screenName);

    // Poll for screen changes
    const interval = setInterval(() => {
      const currentScreen = getCurrentScreen();
      if (currentScreen !== screenName) {
        console.log('Screen changed to:', currentScreen);
        setScreenName(currentScreen);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [screenName]);

  return (
    <div className="app">
      {screenName === 'login-id' && <LoginId />}
      {screenName === 'login-password' && <LoginPassword />}
      {screenName === 'signup-id' && <SignupId />}
      {screenName === 'signup-password' && <SignupPassword />}
      {screenName === 'email-identifier-challenge' && <EmailIdentifierChallenge />}
      {screenName === 'phone-identifier-challenge' && <PhoneIdentifierChallenge />}
      {screenName === 'mfa-email-challenge' && <MfaEmailChallenge />}
      {screenName === 'reset-password-request' && <ResetPasswordRequest />}
      {screenName === 'reset-password' && <ResetPassword />}
      {screenName === 'reset-password-success' && <ResetPasswordSuccess />}
      {!screenName && (
        <div className="loading">
          <p>Loading...</p>
        </div>
      )}
    </div>
  );
}

export default App;
