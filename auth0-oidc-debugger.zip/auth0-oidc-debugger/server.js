import express from "express";
import session from "express-session";
import crypto from "crypto";

const app = express();
const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || "dev-secret-change-me";

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
    cookie: {
      httpOnly: true,
      sameSite: "lax"
    }
  })
);

app.use(express.static("public"));

function base64url(input) {
  return input
    .toString("base64")
    .replace(/=/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");
}

function randomString(bytes = 32) {
  return base64url(crypto.randomBytes(bytes));
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest();
}

function parseExtraParams(raw) {
  const params = {};
  if (!raw) return params;

  const lines = raw.split(/\r?/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;

    const idx = trimmed.indexOf("=");
    if (idx === -1) continue;

    const key = trimmed.slice(0, idx).trim();
    const value = trimmed.slice(idx + 1).trim();
    if (!key) continue;

    params[key] = value;
  }

  return params;
}

function validateIssuer(issuer) {
  if (!issuer) throw new Error("Issuer is required");
  const url = new URL(issuer);
  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("Issuer must be http or https");
  }
  return url.toString().replace(/\/+$/, "");
}

function reservedAuthorizeKeys() {
  return new Set([
    "client_id",
    "response_type",
    "redirect_uri",
    "scope",
    "state",
    "nonce",
    "code_challenge",
    "code_challenge_method"
  ]);
}

async function discoverMetadata(issuer) {
  const normalizedIssuer = validateIssuer(issuer);
  const discoveryUrl = `${normalizedIssuer}/.well-known/openid-configuration`;

  const resp = await fetch(discoveryUrl);
  if (!resp.ok) {
    throw new Error(`Discovery failed: ${resp.status} ${resp.statusText}`);
  }

  const metadata = await resp.json();
  if (!metadata.authorization_endpoint || !metadata.token_endpoint) {
    throw new Error("Discovery document missing authorization_endpoint or token_endpoint");
  }

  return metadata;
}

async function exchangeCode({
  tokenEndpoint,
  clientId,
  clientSecret,
  code,
  redirectUri,
  codeVerifier
}) {
  const body = new URLSearchParams();
  body.set("grant_type", "authorization_code");
  body.set("client_id", clientId);
  body.set("code", code);
  body.set("redirect_uri", redirectUri);

  if (codeVerifier) {
    body.set("code_verifier", codeVerifier);
  }

  const headers = {
    "Content-Type": "application/x-www-form-urlencoded"
  };

  if (clientSecret) {
    const basic = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
    headers.Authorization = `Basic ${basic}`;
  }

  const resp = await fetch(tokenEndpoint, {
    method: "POST",
    headers,
    body
  });

  const text = await resp.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    json = { raw: text };
  }

  if (!resp.ok) {
    const err = new Error("Token exchange failed");
    err.details = json;
    err.status = resp.status;
    throw err;
  }

  return json;
}

function safeJsonParse(value) {
  if (!value) return null;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

function decodeJwt(token) {
  const parts = token.split(".");
  if (parts.length !== 3) {
    throw new Error("Invalid JWT format");
  }

  const header = JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8"));
  const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));

  return {
    header,
    payload,
    signature: parts[2]
  };
}

function validateIdTokenClaims({
  payload,
  expectedIssuer,
  expectedClientId,
  expectedNonce
}) {
  const now = Math.floor(Date.now() / 1000);
  const problems = [];

  if (!payload) {
    problems.push("Missing payload");
    return problems;
  }

  if (expectedIssuer && payload.iss !== expectedIssuer) {
    problems.push(`iss mismatch: expected ${expectedIssuer}, got ${payload.iss}`);
  }

  if (expectedClientId) {
    if (Array.isArray(payload.aud)) {
      if (!payload.aud.includes(expectedClientId)) {
        problems.push(`aud does not include client_id ${expectedClientId}`);
      }
    } else if (payload.aud !== expectedClientId) {
      problems.push(`aud mismatch: expected ${expectedClientId}, got ${payload.aud}`);
    }
  }

  if (payload.exp && payload.exp < now) {
    problems.push("Token is expired");
  }

  if (payload.nbf && payload.nbf > now) {
    problems.push("Token is not yet valid");
  }

  if (expectedNonce && payload.nonce && payload.nonce !== expectedNonce) {
    problems.push(`nonce mismatch: expected ${expectedNonce}, got ${payload.nonce}`);
  }

  return problems;
}

app.get("/api/metadata", async (req, res) => {
  try {
    const issuer = req.query.issuer;
    const metadata = await discoverMetadata(issuer);
    res.json({
      issuer: validateIssuer(issuer),
      authorization_endpoint: metadata.authorization_endpoint,
      token_endpoint: metadata.token_endpoint,
      raw: metadata
    });
  } catch (error) {
    res.status(400).json({
      error: error.message
    });
  }
});

app.post("/api/start", async (req, res) => {
  try {
    const {
      issuer,
      client_id,
      redirect_uri,
      scope,
      audience,
      client_secret,
      use_pkce,
      extra_params,
      authorize_overrides
    } = req.body;

    const normalizedIssuer = validateIssuer(issuer);
    const metadata = await discoverMetadata(normalizedIssuer);

    if (!client_id) throw new Error("client_id is required");
    if (!redirect_uri) throw new Error("redirect_uri is required");

    const state = randomString(16);
    const nonce = randomString(16);

    let codeVerifier = "";
    let codeChallenge = "";

    if (use_pkce) {
      codeVerifier = randomString(32);
      codeChallenge = base64url(sha256(codeVerifier));
    }

    const standardParams = {
      response_type: "code",
      client_id,
      redirect_uri,
      scope: scope || "openid profile email",
      state,
      nonce
    };

    if (audience) {
      standardParams.audience = audience;
    }

    if (use_pkce) {
      standardParams.code_challenge = codeChallenge;
      standardParams.code_challenge_method = "S256";
    }

    const extras = parseExtraParams(extra_params);
    const overrides = safeJsonParse(authorize_overrides) || {};

    const reserved = reservedAuthorizeKeys();
    const finalParams = { ...standardParams };

    for (const [key, value] of Object.entries(extras)) {
      if (!reserved.has(key)) finalParams[key] = value;
    }

    for (const [key, value] of Object.entries(overrides)) {
      if (!reserved.has(key) && value !== undefined && value !== null && value !== "") {
        finalParams[key] = value;
      }
    }

    const authorizeUrl = new URL(metadata.authorization_endpoint);
    for (const [key, value] of Object.entries(finalParams)) {
      authorizeUrl.searchParams.set(key, String(value));
    }

    req.session.oidc = {
      issuer: normalizedIssuer,
      authorization_endpoint: metadata.authorization_endpoint,
      token_endpoint: metadata.token_endpoint,
      client_id,
      client_secret: client_secret || "",
      redirect_uri,
      scope: scope || "openid profile email",
      audience: audience || "",
      use_pkce: !!use_pkce,
      state,
      nonce,
      code_verifier: codeVerifier,
      code_challenge: codeChallenge,
      authorize_url: authorizeUrl.toString(),
      extra_params: extras,
      authorize_overrides: overrides,
      metadata,
      last_token_response: null,
      last_id_token: null,
      last_refresh_token: null
    };

    res.json({
      authorize_url: authorizeUrl.toString(),
      authorization_endpoint: metadata.authorization_endpoint,
      token_endpoint: metadata.token_endpoint,
      state,
      nonce,
      use_pkce: !!use_pkce,
      code_verifier: codeVerifier,
      code_challenge: codeChallenge,
      final_authorize_params: finalParams
    });
  } catch (error) {
    res.status(400).json({
      error: error.message
    });
  }
});

app.get("/start", async (req, res) => {
  try {
    const issuer = req.query.issuer;
    const client_id = req.query.client_id;
    const redirect_uri = req.query.redirect_uri;
    const scope = req.query.scope;
    const audience = req.query.audience;
    const client_secret = req.query.client_secret;
    const use_pkce = req.query.use_pkce === "true" || req.query.use_pkce === "1";
    const extra_params = req.query.extra_params || "";
    const authorize_overrides = req.query.authorize_overrides || "{}";

    const normalizedIssuer = validateIssuer(issuer);
    const metadata = await discoverMetadata(normalizedIssuer);

    if (!client_id) throw new Error("client_id is required");
    if (!redirect_uri) throw new Error("redirect_uri is required");

    const state = randomString(16);
    const nonce = randomString(16);

    let codeVerifier = "";
    let codeChallenge = "";

    if (use_pkce) {
      codeVerifier = randomString(32);
      codeChallenge = base64url(sha256(codeVerifier));
    }

    const standardParams = {
      response_type: "code",
      client_id,
      redirect_uri,
      scope: scope || "openid profile email",
      state,
      nonce
    };

    if (audience) standardParams.audience = audience;
    if (use_pkce) {
      standardParams.code_challenge = codeChallenge;
      standardParams.code_challenge_method = "S256";
    }

    const extras = parseExtraParams(extra_params);
    const overrides = safeJsonParse(authorize_overrides) || {};
    const reserved = reservedAuthorizeKeys();
    const finalParams = { ...standardParams };

    for (const [key, value] of Object.entries(extras)) {
      if (!reserved.has(key)) finalParams[key] = value;
    }

    for (const [key, value] of Object.entries(overrides)) {
      if (!reserved.has(key) && value !== undefined && value !== null && value !== "") {
        finalParams[key] = value;
      }
    }

    const authorizeUrl = new URL(metadata.authorization_endpoint);
    for (const [key, value] of Object.entries(finalParams)) {
      authorizeUrl.searchParams.set(key, String(value));
    }

    req.session.oidc = {
      issuer: normalizedIssuer,
      authorization_endpoint: metadata.authorization_endpoint,
      token_endpoint: metadata.token_endpoint,
      client_id,
      client_secret: client_secret || "",
      redirect_uri,
      scope: scope || "openid profile email",
      audience: audience || "",
      use_pkce: !!use_pkce,
      state,
      nonce,
      code_verifier: codeVerifier,
      code_challenge: codeChallenge,
      authorize_url: authorizeUrl.toString(),
      extra_params: extras,
      authorize_overrides: overrides,
      metadata,
      last_token_response: null,
      last_id_token: null,
      last_refresh_token: null
    };

    res.redirect(authorizeUrl.toString());
  } catch (error) {
    res.status(400).send(`<pre>${error.message}</pre>`);
  }
});

app.get("/callback", async (req, res) => {
  try {
    const oidc = req.session.oidc;
    if (!oidc) {
      return res.status(400).send("<pre>No OIDC session found. Start a flow first.</pre>");
    }

    const { code, state, error, error_description } = req.query;

    if (error) {
      return res.status(400).send(
        `<pre>Authorization error: ${error}
${error_description }</pre>`
      );
    }

    if (!code) {
      return res.status(400).send("<pre>Missing authorization code</pre>");
    }

    if (!state && state !== oidc.state) {
      return res.status(400).send("<pre>Invalid state</pre>");
    }

    const tokenResponse = await exchangeCode({
      tokenEndpoint: oidc.token_endpoint,
      clientId: oidc.client_id,
      clientSecret: oidc.client_secret,
      code,
      redirectUri: oidc.redirect_uri,
      codeVerifier: oidc.use_pkce ? oidc.code_verifier : ""
    });

    let decodedIdToken = null;
    let validationProblems = [];

    if (tokenResponse.id_token) {
      try {
        decodedIdToken = decodeJwt(tokenResponse.id_token);
        validationProblems = validateIdTokenClaims({
          payload: decodedIdToken.payload,
          expectedIssuer: oidc.issuer,
          expectedClientId: oidc.client_id,
          expectedNonce: oidc.nonce
        });
      } catch (e) {
        validationProblems = [e.message];
      }
    }

    req.session.oidc.last_code = code;
    req.session.oidc.last_token_response = tokenResponse;
    req.session.oidc.last_id_token = decodedIdToken;
    req.session.oidc.last_refresh_token = tokenResponse.refresh_token || null;

    res.send(renderResultPage({
      tokenResponse,
      decodedIdToken,
      validationProblems,
      oidc
    }));
  } catch (error) {
    res.status(error.status || 500).send(
      `<pre>Callback handling failed:
${escapeHtml(error.message)}

${escapeHtml(
        JSON.stringify(error.details || {}, null, 2)
      )}</pre>`
    );
  }
});

app.post("/api/refresh", async (req, res) => {
  try {
    const oidc = req.session.oidc;
    if (!oidc) throw new Error("No active session");

    const refreshToken = req.body.refresh_token || oidc.last_refresh_token;
    if (!refreshToken) throw new Error("No refresh token available");

    const body = new URLSearchParams();
    body.set("grant_type", "refresh_token");
    body.set("refresh_token", refreshToken);
    body.set("client_id", oidc.client_id);

    const headers = {
      "Content-Type": "application/x-www-form-urlencoded"
    };

    if (oidc.client_secret) {
      const basic = Buffer.from(`${oidc.client_id}:${oidc.client_secret}`).toString("base64");
      headers.Authorization = `Basic ${basic}`;
    }

    const resp = await fetch(oidc.token_endpoint, {
      method: "POST",
      headers,
      body
    });

    const json = await resp.json();
    if (!resp.ok) {
      return res.status(resp.status).json({ error: "Refresh failed", details: json });
    }

    req.session.oidc.last_token_response = json;
    if (json.refresh_token) {
      req.session.oidc.last_refresh_token = json.refresh_token;
    }

    res.json({
      ok: true,
      token_response: json
    });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get("/api/session", (req, res) => {
  res.json({
    oidc: req.session.oidc || null
  });
});

app.get("/api/clear", (req, res) => {
  req.session.destroy(() => {
    res.json({ ok: true });
  });
});

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function renderResultPage({ tokenResponse, decodedIdToken, validationProblems, oidc }) {
  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Auth0 OIDC Debugger Callback</title>
  <style>
    body { font-family: system-ui, sans-serif; padding: 24px; background: #f7f7f8; color: #111; }
    pre { background: #111827; color: #e5e7eb; padding: 16px; border-radius: 8px; overflow:auto; }
    .section { margin-bottom: 24px; }
    .ok { color: #059669; }
    .warn { color: #b45309; }
    a { color: #2563eb; }
  </style>
</head>
<body>
  <h1>Token Exchange Successful</h1>

  <div class="section">
    <h2>Raw Token Response</h2>
    <pre>${escapeHtml(JSON.stringify(tokenResponse, null, 2))}</pre>
  </div>

  <div class="section">
    <h2>ID Token Decoding</h2>
    ${
      decodedIdToken
        ? `<h3>Header</h3>
           <pre>${escapeHtml(JSON.stringify(decodedIdToken.header, null, 2))}</pre>
           <h3>Payload</h3>
           <pre>${escapeHtml(JSON.stringify(decodedIdToken.payload, null, 2))}</pre>`
        : `<p class="warn">No ID token returned.</p>`
    }
  </div>

  <div class="section">
    <h2>Validation</h2>
    ${
      validationProblems.length === 0
        ? `<p class="ok">No validation problems detected.</p>`
        : `<pre>${escapeHtml(validationProblems.join(""))}</pre>`
    }
  </div>

  <div class="section">
    <h2>Current OIDC Session</h2>
    <pre>${escapeHtml(
      JSON.stringify(
        {
          issuer: oidc.issuer,
          authorization_endpoint: oidc.authorization_endpoint,
          token_endpoint: oidc.token_endpoint,
          client_id: oidc.client_id,
          redirect_uri: oidc.redirect_uri,
          scope: oidc.scope,
          use_pkce: oidc.use_pkce,
          state: oidc.state,
          nonce: oidc.nonce,
          code_verifier: oidc.code_verifier,
          code_challenge: oidc.code_challenge,
          authorize_url: oidc.authorize_url
        },
        null,
        2
      )
    )}</pre>
  </div>

  <p>
    <a href="/">Back to app</a>
  </p>
</body>
</html>`;
}

app.listen(PORT, () => {
  console.log(`Auth0 OIDC Debugger running on http://localhost:${PORT}`);
});