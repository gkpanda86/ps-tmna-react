const STORAGE_KEYS = {
  configs: "auth0_oidc_debugger_configs",
  recentRuns: "auth0_oidc_debugger_recent_runs",
  lastConfig: "auth0_oidc_debugger_last_config"
};

const els = {
  issuer: document.getElementById("issuer"),
  client_id: document.getElementById("client_id"),
  client_secret: document.getElementById("client_secret"),
  redirect_uri: document.getElementById("redirect_uri"),
  scope: document.getElementById("scope"),
  audience: document.getElementById("audience"),
  use_pkce: document.getElementById("use_pkce"),
  config_name: document.getElementById("config_name"),
  prompt: document.getElementById("prompt"),
  extra_params: document.getElementById("extra_params"),
  authorize_overrides: document.getElementById("authorize_overrides"),
  metadataOutput: document.getElementById("metadataOutput"),
  sessionOutput: document.getElementById("sessionOutput"),
  idTokenOutput: document.getElementById("idTokenOutput"),
  validationOutput: document.getElementById("validationOutput"),
  recentRunsOutput: document.getElementById("recentRunsOutput"),
  authUrlEditor: document.getElementById("authUrlEditor"),
  openAuthUrlLink: document.getElementById("openAuthUrlLink"),
  authorization_endpoint: document.getElementById("authorization_endpoint"),
  token_endpoint: document.getElementById("token_endpoint"),
  stateField: document.getElementById("stateField"),
  nonceField: document.getElementById("nonceField"),
  codeVerifierField: document.getElementById("codeVerifierField"),
  codeChallengeField: document.getElementById("codeChallengeField"),
  savedConfigsList: document.getElementById("savedConfigsList"),
  paramRows: document.getElementById("paramRows")
};

const buttons = {
  discoverBtn: document.getElementById("discoverBtn"),
  startBtn: document.getElementById("startBtn"),
  clearBtn: document.getElementById("clearBtn"),
  copyAuthUrlBtn: document.getElementById("copyAuthUrlBtn"),
  refreshBtn: document.getElementById("refreshBtn"),
  saveConfigBtn: document.getElementById("saveConfigBtn"),
  newConfigBtn: document.getElementById("newConfigBtn"),
  addParamBtn: document.getElementById("addParamBtn"),
  applyAuthUrlBtn: document.getElementById("applyAuthUrlBtn")
};

let latestAuthUrl = "";
let activeMetadata = null;
let activeSession = null;

function loadLocal(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
  } catch {
    return fallback;
  }
}

function saveLocal(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function addParamRow(key = "", value = "") {
  const row = document.createElement("div");
  row.className = "param-row";
  row.innerHTML = `
    <input class="param-key" placeholder="key" value="${escapeAttr(key)}" />
    <input class="param-value" placeholder="value" value="${escapeAttr(value)}" />
    <button type="button" class="secondary remove-param">Remove</button>
  `;
  row.querySelector(".remove-param").addEventListener("click", () => row.remove());
  els.paramRows.appendChild(row);
}

function getParamRows() {
  return [...els.paramRows.querySelectorAll(".param-row")].map((row) => ({
    key: row.querySelector(".param-key").value.trim(),
    value: row.querySelector(".param-value").value.trim()
  })).filter((x) => x.key);
}

function setParamRows(items) {
  els.paramRows.innerHTML = "";
  items.forEach((item) => addParamRow(item.key, item.value));
}

function buildOverridesObject() {
  const out = {};
  for (const { key, value } of getParamRows()) {
    out[key] = value;
  }
  return out;
}

function updateExtrasFromRows() {
  const rows = getParamRows();
  els.extra_params.value = rows.map(({ key, value }) => `${key}=${value}`).join("");
}

function populateRowsFromText() {
  const rows = els.extra_params.value
    .split(/\r?/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const idx = line.indexOf("=");
      if (idx === -1) return null;
      return { key: line.slice(0, idx).trim(), value: line.slice(idx + 1).trim() };
    })
    .filter(Boolean);
  setParamRows(rows);
}

function escapeAttr(value) {
  return String(value).replace(/"/g, "&quot;");
}

function pretty(obj) {
  return JSON.stringify(obj, null, 2);
}

function decodeJwt(token) {
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Invalid JWT");
  const header = JSON.parse(atob(parts[0].replace(/-/g, "+").replace(/_/g, "/")));
  const payload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
  return { header, payload, signature: parts[2] };
}

function computePkceChallenge(verifier) {
  const encoder = new TextEncoder();
  return crypto.subtle.digest("SHA-256", encoder.encode(verifier)).then((buf) => {
    const bytes = new Uint8Array(buf);
    let str = "";
    for (const b of bytes) str += String.fromCharCode(b);
    return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
  });
}

async function loadSession() {
  const resp = await fetch("/api/session");
  const data = await resp.json();
  activeSession = data.oidc;
  els.sessionOutput.textContent = pretty(data);
  renderSessionData();
}

function renderSessionData() {
  if (!activeSession) {
    els.authorization_endpoint.value = "";
    els.token_endpoint.value = "";
    els.stateField.value = "";
    els.nonceField.value = "";
    els.codeVerifierField.value = "";
    els.codeChallengeField.value = "";
    els.authUrlEditor.value = "";
    els.openAuthUrlLink.href = "#";
    els.idTokenOutput.textContent = "No ID token decoded yet.";
    els.validationOutput.textContent = "No validation result yet.";
    return;
  }

  els.authorization_endpoint.value = activeSession.authorization_endpoint || "";
  els.token_endpoint.value = activeSession.token_endpoint || "";
  els.stateField.value = activeSession.state || "";
  els.nonceField.value = activeSession.nonce || "";
  els.codeVerifierField.value = activeSession.code_verifier || "";
  els.codeChallengeField.value = activeSession.code_challenge || "";
  els.authUrlEditor.value = activeSession.authorize_url || "";
  latestAuthUrl = activeSession.authorize_url || "";
  els.openAuthUrlLink.href = latestAuthUrl || "#";

  if (activeSession.last_id_token?.payload) {
    els.idTokenOutput.textContent = pretty(activeSession.last_id_token);
  }

  if (activeSession.last_token_response) {
    const refresh = activeSession.last_refresh_token || activeSession.last_token_response.refresh_token || null;
    const enriched = {
      token_response: activeSession.last_token_response,
      refresh_token_available: !!refresh,
      refresh_token: refresh
    };
    els.sessionOutput.textContent = pretty(enriched);
  }

  if (activeSession.last_token_response?.id_token && !activeSession.last_id_token) {
    try {
      els.idTokenOutput.textContent = pretty(decodeJwt(activeSession.last_token_response.id_token));
    } catch (e) {
      els.idTokenOutput.textContent = `Failed to decode ID token: ${e.message}`;
    }
  }

  if (activeSession.last_token_response?.id_token) {
    const idToken = activeSession.last_token_response.id_token;
    try {
      const decoded = decodeJwt(idToken);
      els.idTokenOutput.textContent = pretty(decoded);

      const payload = decoded.payload;
      const problems = [];

      if (activeSession.issuer && payload.iss !== activeSession.issuer) {
        problems.push(`iss mismatch: ${payload.iss}`);
      }
      if (payload.aud) {
        if (Array.isArray(payload.aud)) {
          if (!payload.aud.includes(activeSession.client_id)) {
            problems.push("aud does not include client_id");
          }
        } else if (payload.aud !== activeSession.client_id) {
          problems.push(`aud mismatch: ${payload.aud}`);
        }
      }
      const now = Math.floor(Date.now() / 1000);
      if (payload.exp && payload.exp < now) problems.push("expired");
      if (payload.nbf && payload.nbf > now) problems.push("not yet valid");
      if (payload.nonce && payload.nonce !== activeSession.nonce) problems.push("nonce mismatch");

      els.validationOutput.textContent = problems.length
        ? `Validation problems:
${problems.join("")}`
        : "Validation passed.";
    } catch (e) {
      els.idTokenOutput.textContent = `Failed to decode ID token: ${e.message}`;
    }
  }
}

async function discover() {
  const issuer = els.issuer.value.trim();
  if (!issuer) return alert("Enter issuer URL first.");
  els.metadataOutput.textContent = "Loading...";
  const resp = await fetch(`/api/metadata?issuer=${encodeURIComponent(issuer)}`);
  const data = await resp.json();
  if (!resp.ok) {
    els.metadataOutput.textContent = `Error: ${data.error || "Discovery failed"}`;
    return;
  }
  activeMetadata = data;
  els.metadataOutput.textContent = pretty(data);
}

async function startFlow(e) {
  e.preventDefault();
  updateExtrasFromRows();

  const payload = {
    issuer: els.issuer.value.trim(),
    client_id: els.client_id.value.trim(),
    client_secret: els.client_secret.value,
    redirect_uri: els.redirect_uri.value.trim(),
    scope: els.scope.value.trim(),
    audience: els.audience.value.trim(),
    use_pkce: els.use_pkce.checked,
    extra_params: els.extra_params.value,
    authorize_overrides: els.authorize_overrides.value
  };

  els.authUrlEditor.value = "Starting...";
  const resp = await fetch("/api/start", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  const data = await resp.json();
  if (!resp.ok) {
    els.authUrlEditor.value = `Error: ${data.error || "Failed to start flow"}`;
    return;
  }

  latestAuthUrl = data.authorize_url;
  els.authUrlEditor.value = latestAuthUrl;
  els.openAuthUrlLink.href = latestAuthUrl;
  await saveRecentRun({
    name: els.config_name.value || "Untitled",
    issuer: payload.issuer,
    client_id: payload.client_id,
    timestamp: new Date().toISOString(),
    pkce: payload.use_pkce,
    authorization_endpoint: data.authorization_endpoint,
    token_endpoint: data.token_endpoint
  });
  await loadSession();
  renderRecentRuns();
  window.location.href = latestAuthUrl;
}

async function refreshTokens() {
  const session = activeSession;
  if (!session) return alert("No active session.");
  const refreshToken =
    session.last_refresh_token ||
    session.last_token_response?.refresh_token ||
    prompt("Enter refresh token:");
  if (!refreshToken) return;

  const resp = await fetch("/api/refresh", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: refreshToken })
  });
  const data = await resp.json();
  if (!resp.ok) {
    alert(data.error || "Refresh failed");
    return;
  }

  await loadSession();
  renderRecentRuns();
}

function getConfigs() {
  return loadLocal(STORAGE_KEYS.configs, []);
}

function saveConfigs(configs) {
  saveLocal(STORAGE_KEYS.configs, configs);
}

function saveCurrentConfig() {
  const config = {
    name: els.config_name.value.trim() || `Config ${Date.now()}`,
    issuer: els.issuer.value.trim(),
    client_id: els.client_id.value.trim(),
    client_secret: els.client_secret.value,
    redirect_uri: els.redirect_uri.value.trim(),
    scope: els.scope.value.trim(),
    audience: els.audience.value.trim(),
    use_pkce: els.use_pkce.checked,
    extra_params: els.extra_params.value,
    authorize_overrides: els.authorize_overrides.value
  };

  const configs = getConfigs();
  const existing = configs.findIndex((c) => c.name === config.name);
  if (existing >= 0) configs[existing] = config;
  else configs.unshift(config);
  saveConfigs(configs);
  renderSavedConfigs();
}

function renderSavedConfigs() {
  const configs = getConfigs();
  els.savedConfigsList.innerHTML = "";
  if (!configs.length) {
    els.savedConfigsList.innerHTML = "<p>No saved configs.</p>";
    return;
  }

  configs.forEach((config, idx) => {
    const div = document.createElement("div");
    div.className = "saved-item";
    div.innerHTML = `
      <div>
        <strong>${escapeAttr(config.name)}</strong>
        <div class="muted">${escapeAttr(config.issuer || "")}</div>
      </div>
      <div class="saved-actions">
        <button type="button" class="secondary load">Load</button>
        <button type="button" class="secondary delete">Delete</button>
      </div>
    `;
    div.querySelector(".load").addEventListener("click", () => loadConfig(config));
    div.querySelector(".delete").addEventListener("click", () => {
      configs.splice(idx, 1);
      saveConfigs(configs);
      renderSavedConfigs();
    });
    els.savedConfigsList.appendChild(div);
  });
}

function loadConfig(config) {
  els.config_name.value = config.name || "";
  els.issuer.value = config.issuer || "";
  els.client_id.value = config.client_id || "";
  els.client_secret.value = config.client_secret || "";
  els.redirect_uri.value = config.redirect_uri || "";
  els.scope.value = config.scope || "openid profile email offline_access";
  els.audience.value = config.audience || "";
  els.use_pkce.checked = !!config.use_pkce;
  els.extra_params.value = config.extra_params || "";
  els.authorize_overrides.value = config.authorize_overrides || "";
  populateRowsFromText();
  localStorage.setItem(STORAGE_KEYS.lastConfig, JSON.stringify(config));
}

function saveRecentRun(run) {
  const runs = loadLocal(STORAGE_KEYS.recentRuns, []);
  runs.unshift(run);
  saveLocal(STORAGE_KEYS.recentRuns, runs.slice(0, 20));
}

function renderRecentRuns() {
  const runs = loadLocal(STORAGE_KEYS.recentRuns, []);
  els.recentRunsOutput.textContent = runs.length ? pretty(runs) : "No runs yet.";
}

function clearSession() {
  fetch("/api/clear").then(() => loadSession());
}

function applyAuthUrlEdits() {
  latestAuthUrl = els.authUrlEditor.value.trim();
  els.openAuthUrlLink.href = latestAuthUrl || "#";
}

buttons.discoverBtn.addEventListener("click", discover);
buttons.startBtn.addEventListener("click", () => {});
buttons.clearBtn.addEventListener("click", clearSession);
buttons.copyAuthUrlBtn.addEventListener("click", async () => {
  if (!latestAuthUrl) return alert("No authorization URL to copy.");
  await navigator.clipboard.writeText(latestAuthUrl);
  alert("Copied.");
});
buttons.refreshBtn.addEventListener("click", refreshTokens);
buttons.saveConfigBtn.addEventListener("click", saveCurrentConfig);
buttons.newConfigBtn.addEventListener("click", () => {
  localStorage.removeItem(STORAGE_KEYS.lastConfig);
  els.config_name.value = "";
  els.issuer.value = "";
  els.client_id.value = "";
  els.client_secret.value = "";
  els.redirect_uri.value = "http://localhost:3000/callback";
  els.scope.value = "openid profile email offline_access";
  els.audience.value = "";
  els.use_pkce.checked = true;
  els.extra_params.value = "";
  els.authorize_overrides.value = "";
  setParamRows([]);
});
buttons.addParamBtn.addEventListener("click", () => addParamRow());
buttons.applyAuthUrlBtn.addEventListener("click", applyAuthUrlEdits);
flowForm.addEventListener("submit", startFlow);

els.extra_params.addEventListener("input", populateRowsFromText);

(function init() {
  renderSavedConfigs();
  renderRecentRuns();
  addParamRow();
  const lastConfigRaw = localStorage.getItem(STORAGE_KEYS.lastConfig);
  if (lastConfigRaw) {
    try {
      loadConfig(JSON.parse(lastConfigRaw));
    } catch {}
  }
  loadSession();
})();