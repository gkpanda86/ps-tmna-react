# MyToyota - Auth0 Demo SPA

A React single-page application demonstrating authentication and authorization using Auth0 as the identity provider, featuring Toyota-specific branding.

## Features

- **Auth0 Integration**: Complete authentication flow with login and signup
- **Token Management**: In-memory token storage (id_token and access_token)
- **Silent Authentication**: Automatic token refresh without refresh tokens
- **Toyota Branding**: Custom styling with Toyota colors and design
- **Protected Routes**: Dashboard and profile pages requiring authentication
- **User Profile Editor**: Form to edit user information with API integration
- **API Demo**: Demonstrates making authenticated API calls with Bearer tokens

## Tech Stack

- **React 18** with TypeScript
- **Vite** for fast development and builds
- **Tailwind CSS** for styling
- **Auth0 React SDK** for authentication
- **React Router** for navigation

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- An Auth0 account and application

### Auth0 Configuration

1. Create an Auth0 account at [auth0.com](https://auth0.com)
2. Create a new Single Page Application in your Auth0 dashboard
3. Configure the following settings in your Auth0 application:
   - **Allowed Callback URLs**: `http://localhost:5173/callback`
   - **Allowed Logout URLs**: `http://localhost:5173`
   - **Allowed Web Origins**: `http://localhost:5173`
4. Note your Domain and Client ID

### Installation

1. Clone the repository and navigate to the project directory

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file in the root directory (copy from `.env.example`):
   ```bash
   cp .env.example .env
   ```

4. Update the `.env` file with your Auth0 credentials:
   ```
   VITE_AUTH0_DOMAIN=your-domain.auth0.com
   VITE_AUTH0_CLIENT_ID=your-client-id
   VITE_AUTH0_REDIRECT_URI=http://localhost:5173/callback
   VITE_AUTH0_AUDIENCE=  # Optional: your API audience if configured
   ```

### Development

Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5173`

### Build

Create a production build:
```bash
npm run build
```

Preview the production build:
```bash
npm run preview
```

## Application Flow

1. **Landing Page** (`/`):
   - Toyota-branded homepage with navigation dropdown
   - Sign In and Create Account options
   - Redirects to Auth0 for authentication

2. **Callback Page** (`/callback`):
   - Handles Auth0 redirect after authentication
   - Displays welcome message with ID token claims
   - Automatically redirects to dashboard

3. **Dashboard Page** (`/dashboard`):
   - Protected route requiring authentication
   - Displays user profile information
   - Shows ID token claims and access token
   - "Edit Profile" button to navigate to profile editor

4. **My Profile Page** (`/my-profile`):
   - Protected profile editor requiring authentication
   - Form pre-populated with user's first and last name from ID token
   - On submit, makes POST request to demo API endpoint
   - Access token passed as Bearer token in Authorization header

## Authentication Details

- **Token Storage**: Tokens are stored in memory only (not localStorage or sessionStorage)
- **Token Types**: Only id_token and access_token (no refresh token)
- **Silent Authentication**: Configured in Auth0Provider with `useRefreshTokens={false}` and `cacheLocation="memory"`
- **Token Expiration**: When tokens expire, Auth0 SDK automatically performs silent authentication

## Project Structure

```
src/
├── components/        # Reusable components (currently empty)
├── pages/            # Page components
│   ├── Landing.tsx   # Landing page with navigation
│   ├── Callback.tsx  # Auth0 callback handler
│   ├── Dashboard.tsx # Protected dashboard page
│   └── MyProfile.tsx # Protected profile editor
├── utils/            # Utility functions (currently empty)
├── App.tsx           # Main app component with routing
└── main.tsx          # App entry point with Auth0Provider
```

## License

MIT
