import { useAuth0 } from "@auth0/auth0-react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const {
    user,
    isLoading,
    isAuthenticated,
    logout,
    getIdTokenClaims,
    getAccessTokenSilently,
    loginWithRedirect,
  } = useAuth0();
  const [claims, setClaims] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/");
      return;
    }

    const fetchTokens = async () => {
      try {
        const idTokenClaims = await getIdTokenClaims();
        setClaims(idTokenClaims);

        const token = await getAccessTokenSilently();
        setAccessToken(token);
      } catch (err) {
        console.error("Error fetching tokens:", err);
      }
    };

    if (isAuthenticated) {
      fetchTokens();
    }
  }, [
    isLoading,
    isAuthenticated,
    getIdTokenClaims,
    getAccessTokenSilently,
    navigate,
  ]);

  const handleLogout = () => {
    logout({
      logoutParams: {
        returnTo: window.location.origin,
      },
    });
  };

  const handleEditProfile = async () => {
    // Trigger step-up authentication before allowing profile edit
    await loginWithRedirect({
      authorizationParams: {
        scope: 'openid profile email phone',
        acr_values:
          "http://schemas.openid.net/pape/policies/2007/06/multi-factor",
      },
      appState: {
        returnTo: "/my-profile",
      },
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-toyota-red"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a href="/" className="text-3xl font-bold text-toyota-red">
                TOYOTA
              </a>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-toyota-darkgray">
                {user?.email}
              </span>
              <button
                onClick={handleLogout}
                className="bg-toyota-red text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold text-toyota-darkgray mb-6">
          Dashboard
        </h1>

        {/* User Info Card */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-xl font-semibold text-toyota-darkgray">
              Profile Information
            </h2>
            <button
              onClick={handleEditProfile}
              className="bg-toyota-red text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors text-sm font-medium"
            >
              Edit Profile
            </button>
          </div>
          <div className="flex items-center gap-4">
            {user?.picture && (
              <img
                src={user.picture}
                alt={user.name}
                className="w-16 h-16 rounded-full"
              />
            )}
            <div>
              <p className="text-lg font-medium text-toyota-darkgray">
                {user?.name}
              </p>
              <p className="text-sm text-gray-600">{user?.email}</p>
            </div>
          </div>
        </div>

        {/* Token Information */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* ID Token Claims */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold text-toyota-darkgray mb-4">
              ID Token Claims
            </h2>
            {claims ? (
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-700">
                    Subject (sub)
                  </p>
                  <p className="text-sm text-gray-600 break-all">
                    {claims.sub}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Email</p>
                  <p className="text-sm text-gray-600">{claims.email}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">
                    Email Verified
                  </p>
                  <p className="text-sm text-gray-600">
                    {claims.email_verified ? "Yes" : "No"}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Issued At</p>
                  <p className="text-sm text-gray-600">
                    {new Date(claims.iat * 1000).toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">
                    Expires At
                  </p>
                  <p className="text-sm text-gray-600">
                    {new Date(claims.exp * 1000).toLocaleString()}
                  </p>
                </div>
              </div>
            ) : (
              <p className="text-sm text-gray-500">Loading claims...</p>
            )}
          </div>

          {/* Access Token Info */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold text-toyota-darkgray mb-4">
              Access Token
            </h2>
            {accessToken ? (
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2">
                    Token
                  </p>
                  <div className="bg-gray-50 p-3 rounded border border-gray-200">
                    <p className="text-xs text-gray-600 break-all font-mono">
                      {accessToken.substring(0, 100)}...
                    </p>
                  </div>
                </div>
                <div className="bg-blue-50 border border-blue-200 rounded p-3">
                  <p className="text-sm text-blue-800">
                    <strong>Note:</strong> Token is stored in memory only. If
                    lost or expired, silent authentication will be triggered
                    automatically.
                  </p>
                </div>
              </div>
            ) : (
              <p className="text-sm text-gray-500">Loading token...</p>
            )}
          </div>
        </div>

        {/* Info Section */}
        <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-yellow-800 mb-2">
            Authentication Method
          </h3>
          <p className="text-sm text-yellow-700">
            This application uses Auth0 for authentication. Tokens are stored in
            memory (not localStorage or sessionStorage) for security. When
            tokens expire, silent authentication is performed automatically
            using the Auth0 React SDK.
          </p>
        </div>
      </main>
    </div>
  );
}
