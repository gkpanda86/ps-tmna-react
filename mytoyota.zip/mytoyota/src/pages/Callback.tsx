import { useAuth0 } from '@auth0/auth0-react';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Callback() {
  const { user, isLoading, error } = useAuth0();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && user) {
      // Check if there's a stored returnTo path from step-up authentication
      const returnTo = sessionStorage.getItem('auth_returnTo');
      const redirectTo = returnTo || '/dashboard';

      // Clear the stored path
      if (returnTo) {
        sessionStorage.removeItem('auth_returnTo');
      }

      // Redirect immediately
      navigate(redirectTo);
    }
  }, [isLoading, user, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-toyota-red mx-auto mb-4"></div>
          <p className="text-toyota-darkgray">Processing authentication...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center max-w-md">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Authentication Error</h1>
          <p className="text-toyota-darkgray">{error.message}</p>
          <button
            onClick={() => navigate('/')}
            className="mt-6 bg-toyota-red text-white px-6 py-2 rounded-md hover:bg-red-700 transition-colors"
          >
            Return Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-toyota-red mx-auto mb-4"></div>
        <p className="text-toyota-darkgray">Redirecting...</p>
      </div>
    </div>
  );
}
