import { useAuth0 } from "@auth0/auth0-react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function MyProfile() {
  const {
    user,
    isLoading,
    isAuthenticated,
    getAccessTokenSilently,
    getIdTokenClaims,
    loginWithRedirect,
  } = useAuth0();
  const navigate = useNavigate();

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/");
      return;
    }

    const loadUserData = async () => {
      try {
        const claims = await getIdTokenClaims();

        // Try to extract first and last name from various claim fields
        const givenName = claims?.given_name || "";
        const familyName = claims?.family_name || "";

        // If given_name/family_name not available, try to split the name field
        if (!givenName && !familyName && claims?.name) {
          const nameParts = claims.name.split(" ");
          setFirstName(nameParts[0] || "");
          setLastName(nameParts.slice(1).join(" ") || "");
        } else {
          setFirstName(givenName);
          setLastName(familyName);
        }
      } catch (err) {
        console.error("Error loading user data:", err);
      }
    };

    if (isAuthenticated) {
      loadUserData();
    }
  }, [isLoading, isAuthenticated, getIdTokenClaims, navigate]);

  const handleUpdateEmail = () => {
    // Use Auth0 SDK to redirect with change_email scope
    loginWithRedirect({
      authorizationParams: {
        scope: "openid profile email phone change_email",
      },
      appState: {
        returnTo: "/my-profile",
      },
    });
  };

  const handleUpdatePhone = () => {
    // Use Auth0 SDK to redirect with change_phone scope
    loginWithRedirect({
      authorizationParams: {
        scope: "openid profile email phone change_phone",
      },
      appState: {
        returnTo: "/my-profile",
      },
    });
  };

  const handleChangePassword = () => {
    // Use Auth0 SDK to redirect with change_password scope
    loginWithRedirect({
      authorizationParams: {
        scope: "openid profile email phone change_password",
      },
      appState: {
        returnTo: "/my-profile",
      },
    });
  };

  // Helper function to format phone number and get country info
  const formatPhoneNumber = (phoneNumber: string | undefined) => {
    if (!phoneNumber) return { flag: "🇺🇸", number: "" };

    // Remove all non-digit characters
    const digits = phoneNumber.replace(/\D/g, "");

    // Assume US/Canada (+1) if starts with 1 and has 11 digits
    if (digits.startsWith("1") && digits.length === 11) {
      const tenDigit = digits.slice(1); // Remove country code
      return { flag: "🇺🇸", number: tenDigit };
    }

    // If it's already 10 digits, assume US
    if (digits.length === 10) {
      return { flag: "🇺🇸", number: digits };
    }

    // Default case - return as is
    return { flag: "🇺🇸", number: phoneNumber };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);
    setIsSubmitting(true);

    try {
      // Get the access token
      const accessToken = await getAccessTokenSilently();

      // Make POST request to fake endpoint
      const response = await fetch("http://localhost:3000/user", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          firstName,
          lastName,
          name: firstName + " " + lastName,
          userId: user?.sub,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        console.log("API Response:", data);
        setMessage({
          type: "success",
          text: "Profile updated successfully!",
        });
      } else {
        throw new Error("Failed to update profile");
      }
    } catch (err) {
      console.error("Error updating profile:", err);
      setMessage({
        type: "error",
        text: "Failed to update profile. Please try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-toyota-red"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a href="/" className="text-3xl font-bold text-toyota-red">
                TOYOTA
              </a>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate("/dashboard")}
                className="text-toyota-darkgray hover:text-toyota-red font-medium transition-colors"
              >
                Dashboard
              </button>
              <span className="text-sm text-toyota-darkgray">
                {user?.email}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <button
            onClick={() => navigate("/dashboard")}
            className="text-toyota-darkgray hover:text-toyota-red flex items-center gap-2"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 19l-7-7 7-7"
              />
            </svg>
            Back to Dashboard
          </button>
        </div>

        <h1 className="text-3xl font-bold text-toyota-darkgray mb-8">
          Edit Profile
        </h1>

        {/* Profile Form */}
        <div className="bg-white rounded-lg shadow p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* First Name */}
            <div>
              <label
                htmlFor="firstName"
                className="block text-sm font-medium text-toyota-darkgray mb-2"
              >
                First Name
              </label>
              <input
                type="text"
                id="firstName"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-toyota-red focus:border-transparent outline-none transition-all"
                required
              />
            </div>

            {/* Last Name */}
            <div>
              <label
                htmlFor="lastName"
                className="block text-sm font-medium text-toyota-darkgray mb-2"
              >
                Last Name
              </label>
              <input
                type="text"
                id="lastName"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-toyota-red focus:border-transparent outline-none transition-all"
                required
              />
            </div>

            {/* Email (Read Only) */}
            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-toyota-darkgray mb-2"
              >
                Email
              </label>
              <div className="flex gap-3">
                <input
                  type="email"
                  id="email"
                  value={user?.email || ""}
                  disabled
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md bg-gray-50 text-gray-500"
                />
                <button
                  type="button"
                  onClick={handleUpdateEmail}
                  className="px-4 py-2 bg-toyota-red text-white rounded-md font-medium hover:bg-red-700 transition-colors whitespace-nowrap"
                >
                  Update Email
                </button>
              </div>
            </div>

            {/* Phone Number (Read Only) */}
            <div>
              <label
                htmlFor="phone"
                className="block text-sm font-medium text-toyota-darkgray mb-2"
              >
                Phone Number
              </label>
              <div className="flex gap-3">
                <div className="flex-1 flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-md bg-gray-50">
                  <span className="text-2xl">
                    {formatPhoneNumber(user?.phone_number).flag}
                  </span>
                  <input
                    type="tel"
                    id="phone"
                    value={formatPhoneNumber(user?.phone_number).number}
                    disabled
                    className="flex-1 bg-transparent text-gray-500 outline-none"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleUpdatePhone}
                  className="px-4 py-2 bg-toyota-red text-white rounded-md font-medium hover:bg-red-700 transition-colors whitespace-nowrap"
                >
                  Update Phone
                </button>
              </div>
            </div>

            {/* Message */}
            {message && (
              <div
                className={`p-4 rounded-md ${
                  message.type === "success"
                    ? "bg-green-50 text-green-800 border border-green-200"
                    : "bg-red-50 text-red-800 border border-red-200"
                }`}
              >
                {message.text}
              </div>
            )}

            {/* Submit Button */}
            <div className="flex gap-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 bg-toyota-red text-white px-6 py-3 rounded-md font-medium hover:bg-red-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                {isSubmitting ? "Saving..." : "Save Changes"}
              </button>
              <button
                type="button"
                onClick={handleChangePassword}
                className="px-6 py-3 bg-toyota-darkgray text-white rounded-md font-medium hover:bg-gray-700 transition-colors"
              >
                Change Password
              </button>
              <button
                type="button"
                onClick={() => navigate("/dashboard")}
                className="px-6 py-3 border-2 border-gray-300 text-toyota-darkgray rounded-md font-medium hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>

          {/* API Info */}
          {/*<div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-md">
            <p className="text-sm text-blue-800">
              <strong>Note:</strong> This form makes a POST request to{" "}
              <code className="bg-blue-100 px-1 py-0.5 rounded">
                https://jsonplaceholder.typicode.com/users
              </code>{" "}
              with the access token in the Authorization header as a Bearer
              token.
            </p>
          </div>*/}
        </div>
      </main>
    </div>
  );
}
