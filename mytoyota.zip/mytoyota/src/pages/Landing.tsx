import { useAuth0 } from '@auth0/auth0-react';

export default function Landing() {
  const { loginWithRedirect, isAuthenticated, user } = useAuth0();

  const handleSignIn = () => {
    loginWithRedirect({
      authorizationParams: {
        screen_hint: 'login',
        scope: 'openid profile email phone',
      },
    });
  };

  const handleSignUp = () => {
    loginWithRedirect({
      authorizationParams: {
        screen_hint: 'signup',
        scope: 'openid profile email phone',
      },
    });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Toyota Logo */}
            <div className="flex items-center">
              <span className="text-3xl font-bold text-toyota-red">TOYOTA</span>
            </div>

            {/* Navigation */}
            <nav className="flex items-center">
              {!isAuthenticated && (
                <div className="relative group">
                  <button className="text-toyota-darkgray hover:text-toyota-red font-medium px-4 py-2 rounded-md transition-colors">
                    Account
                  </button>

                  {/* Dropdown Menu */}
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-10">
                    <div className="py-1">
                      <button
                        onClick={handleSignIn}
                        className="block w-full text-left px-4 py-2 text-sm text-toyota-darkgray hover:bg-toyota-lightgray transition-colors"
                      >
                        Sign In
                      </button>
                      <button
                        onClick={handleSignUp}
                        className="block w-full text-left px-4 py-2 text-sm text-toyota-darkgray hover:bg-toyota-lightgray transition-colors"
                      >
                        Create Account
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {isAuthenticated && (
                <div className="flex items-center gap-4">
                  <span className="text-sm text-toyota-darkgray">
                    Welcome, {user?.name}
                  </span>
                  <a
                    href="/dashboard"
                    className="bg-toyota-red text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors"
                  >
                    Dashboard
                  </a>
                </div>
              )}
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-toyota-darkgray mb-6">
            Welcome to MyToyota
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Your personalized Toyota experience starts here
          </p>

          {!isAuthenticated && (
            <div className="flex justify-center gap-4">
              <button
                onClick={handleSignIn}
                className="bg-toyota-red text-white px-8 py-3 rounded-md text-lg font-medium hover:bg-red-700 transition-colors"
              >
                Sign In
              </button>
              <button
                onClick={handleSignUp}
                className="bg-white text-toyota-red border-2 border-toyota-red px-8 py-3 rounded-md text-lg font-medium hover:bg-toyota-lightgray transition-colors"
              >
                Create Account
              </button>
            </div>
          )}
        </div>

        {/* Features Section */}
        <div className="mt-20 grid md:grid-cols-3 gap-8">
          <div className="p-6 border border-gray-200 rounded-lg">
            <h3 className="text-xl font-semibold text-toyota-darkgray mb-3">
              Vehicle Management
            </h3>
            <p className="text-gray-600">
              Track your vehicle's maintenance, service history, and more.
            </p>
          </div>
          <div className="p-6 border border-gray-200 rounded-lg">
            <h3 className="text-xl font-semibold text-toyota-darkgray mb-3">
              Exclusive Offers
            </h3>
            <p className="text-gray-600">
              Get access to special promotions and personalized deals.
            </p>
          </div>
          <div className="p-6 border border-gray-200 rounded-lg">
            <h3 className="text-xl font-semibold text-toyota-darkgray mb-3">
              Connected Services
            </h3>
            <p className="text-gray-600">
              Stay connected to your vehicle with remote features and alerts.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
