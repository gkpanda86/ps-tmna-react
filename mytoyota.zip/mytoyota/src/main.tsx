import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Auth0Provider } from "@auth0/auth0-react";
import "./index.css";
import App from "./App.tsx";

const domain =
  import.meta.env.VITE_AUTH0_DOMAIN || "your-auth0-domain.auth0.com";
const clientId = import.meta.env.VITE_AUTH0_CLIENT_ID || "your-client-id";
const redirectUri =
  import.meta.env.VITE_AUTH0_REDIRECT_URI ||
  window.location.origin + "/callback";
const audience = import.meta.env.VITE_AUTH0_AUDIENCE || "";

const onRedirectCallback = (appState?: any) => {
  // Store the returnTo path from appState for the Callback component to use
  if (appState?.returnTo) {
    sessionStorage.setItem('auth_returnTo', appState.returnTo);
  }
  // Keep the URL at /callback to show the welcome message
  window.history.replaceState({}, document.title, '/callback');
};

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <Auth0Provider
      domain={domain}
      clientId={clientId}
      authorizationParams={{
        redirect_uri: redirectUri,
        audience: audience,
      }}
      useRefreshTokens={false}
      useDpop={true}
      cacheLocation="memory"
      onRedirectCallback={onRedirectCallback}
    >
      <App />
    </Auth0Provider>
  </StrictMode>,
);
