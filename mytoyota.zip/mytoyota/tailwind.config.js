/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        toyota: {
          red: '#eb0a1e',
          darkgray: '#58585b',
          lightgray: '#e8e8e8',
        },
      },
    },
  },
  plugins: [],
}

