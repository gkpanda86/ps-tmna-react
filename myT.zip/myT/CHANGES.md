# myT - Toyota.com Clone (React + Vite)

## Project Overview

A React web application mimicking toyota.com, built with Vite and integrated with Auth0 for authentication.

## Tech Stack

- **React 18** with Vite
- **React Router** for client-side routing
- **@auth0/auth0-react** for OIDC authentication
- Auth0 configuration via `.env` file (`VITE_AUTH0_DOMAIN`, `VITE_AUTH0_CLIENT_ID`)

## Pages & Features

### Header (all pages)

- Sticky header with Toyota logo, navigation links (Vehicles, Shop, Support & Service), and Account button
- **Account Dropdown (logged out):** "Personalize Your Toyota Experience" message with "Create Account Or Sign In" button that triggers Auth0 `loginWithRedirect()`
- **Account Dropdown (logged in):** Welcome message with user name/email, Sign Out button, Notifications, My Saves, and Settings (navigates to `/my-dashboard/personal-information`)

### Landing Page (`/`)

- Simple welcome page with header

### Registration Page (`/owners/register`)

**Step 1 - Email Entry:**
- Email input with validation (red border + error message for invalid format)
- "Create Account" button enabled only when email is valid
- "Sign In Instead" link triggers Auth0 login
- SSO buttons (Apple, Google, Meta) trigger Auth0 social login
- "Activate Account" and "Support" links
- Business account section at the bottom
- Supports `?email=` query parameter to pre-fill the email field

**Step 2 - Profile Form (after valid email submitted):**
- Email field (read-only, pre-filled)
- Password and Confirm Password fields with Show/Hide toggles
- Password requirements with green checkmark (met) / red exclamation (unmet) indicators:
  - 8-16 characters
  - Uppercase and lowercase letters
  - A number (0-9)
  - A special character (@ # & % ! ~)
  - Passwords match
- First Name, Last Name, Phone Number fields
- "Create Account" button enabled only when all fields filled and all password requirements met
- On submit: POST to Okta Workflows API with `{ firstName, lastName, email, phone, password }`
- Cancel button returns to Step 1
- "Already have an account?" link triggers Auth0 login

### Personal Information Page (`/my-dashboard/personal-information`)

Accessible from Account dropdown > Settings (when logged in).

**Header section:** "My Account" title with grey background

**Three tabs:**

1. **Personal Information**
   - On page load: POST to Okta Workflows API with `{ email }` from the id_token to fetch profile
   - Form populated with real profile data from API response
   - **MFA-gated editing:** checks `amr` claim in id_token
     - No `amr`: form disabled, data masked, "Edit Information" button triggers Auth0 redirect with `acr_values` for MFA
     - `amr` present: form enabled, data unmasked, "Save" button POSTs updated profile to Okta Workflows API with `{ email, firstName, lastName, id, phone }`
   - Last Name, Phone Number, and Email are masked when not in edit mode (e.g., `P*****`, `(***) ***-9261`, `gop*****@gmail.com`)
   - Fields: First Name, Last Name, Address Line 1 & 2, City, State (dropdown), Zip, Phone Number, Phone Number (Alt), Email Address
   - Privacy note with "Click here" link

2. **Password Settings**
   - "Update Password" title with history warning subtitle
   - Card layout: password fields (left) + requirements (right)
   - **MFA-gated editing:** checks `amr` claim in id_token
     - No `amr`: form disabled, "Update Password" button triggers Auth0 redirect with `acr_values` for MFA (stores active tab in sessionStorage for return)
     - `amr` present: form enabled with Show/Hide toggles, "Save Changes" button enabled when all requirements met
   - Current Password, New Password, Confirm Password fields
   - "Forgot Password?" link
   - Password requirements with green/red indicators (same rules as registration)
   - On submit: POST to Okta Workflows API with `{ id, oldPassword, newPassword }`

3. **Communication Preferences**
   - "Communication Preferences" title
   - Grey card with description text and "Update Preferences" button

## File Structure

```
src/
├── main.jsx                        # App entry, Auth0Provider + BrowserRouter
├── App.jsx                         # Route definitions
├── App.css                         # App-level styles
├── index.css                       # Global reset/base styles
├── components/
│   ├── Header.jsx                  # Sticky header with nav and account dropdown
│   ├── Header.css
│   ├── AccountDropdown.jsx         # Account dropdown (logged in/out states)
│   └── AccountDropdown.css
└── pages/
    ├── Register.jsx                # Two-step registration flow
    ├── Register.css
    ├── PersonalInformation.jsx     # My Account dashboard (3 tabs)
    └── PersonalInformation.css
```

## API Endpoints

### Real APIs (Okta Workflows)

All real APIs are hosted at `demo-tmna-pscollab.workflows.oktapreview.com`.

| Flow | Method | Body | Purpose |
|------|--------|------|---------|
| Registration | POST | `{ firstName, lastName, email, phone, password }` | Account registration |
| Fetch Profile | POST | `{ email }` | Fetch user profile by email from id_token |
| Update Profile | POST | `{ email, firstName, lastName, id, phone }` | Update user profile (MFA required) |
| Change Password | POST | `{ id, oldPassword, newPassword }` | Change password (MFA required) |
