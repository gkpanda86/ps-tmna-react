import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { useAuth0 } from "@auth0/auth0-react";
import "./Register.css";

function Register() {
  const [searchParams] = useSearchParams();
  const { loginWithRedirect } = useAuth0();
  const [email, setEmail] = useState("");
  const [touched, setTouched] = useState(false);
  const [step, setStep] = useState("email");

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");

  useEffect(() => {
    const emailParam = searchParams.get("email");
    if (emailParam) {
      setEmail(emailParam);
      setTouched(true);
    }
  }, [searchParams]);

  const isValidFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const isAliasEmail = /\+/.test(email.split("@")[0]);
  const isValidEmail = isValidFormat && !isAliasEmail;
  const showError = touched && email.length > 0 && !isValidFormat;
  const showAliasError =
    touched && email.length > 0 && isValidFormat && isAliasEmail;
  const isEmailButtonEnabled = email.length > 0 && isValidEmail;

  const passwordRequirements = [
    {
      label: "Use 8-16 Characters",
      met: password.length >= 8 && password.length <= 16,
    },
    {
      label: "Use uppercase and lowercase letters",
      met: /[a-z]/.test(password) && /[A-Z]/.test(password),
    },
    { label: "Use a number (0-9)", met: /\d/.test(password) },
    {
      label: "Use a special character (@ # & % ! ~)",
      met: /[@#&%!~]/.test(password),
    },
    {
      label: "Passwords match",
      met:
        password.length > 0 &&
        confirmPassword.length > 0 &&
        password === confirmPassword,
    },
  ];

  const allRequirementsMet = passwordRequirements.every((r) => r.met);
  const isFormComplete =
    allRequirementsMet &&
    firstName.trim() &&
    lastName.trim() &&
    phoneNumber.length === 10;

  const handleEmailSubmit = () => {
    setStep("profile");
  };

  const handleCreateAccount = async () => {
    const phone = phoneNumber.trim().replace(/\D/g, "");
    const formattedPhone = phone.startsWith("1") ? `+${phone}` : `+1${phone}`;

    const payload = {
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      email,
      phone: formattedPhone,
      password,
    };

    try {
      const response = await fetch(
        "https://demo-tmna-pscollab.workflows.oktapreview.com/api/flo/23e4245c0eb60e795f68a2c59a0a92a6/invoke?clientToken=425ce170600958e708656b9cc7643b4d3db79c16f278dead4e304a7d425d5c47",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        },
      );
      if (response.ok) {
        setStep("success");
      }
    } catch (err) {
      console.error("Registration failed:", err);
    }
  };

  const handleCancel = () => {
    setStep("email");
    setPassword("");
    setConfirmPassword("");
    setFirstName("");
    setLastName("");
    setPhoneNumber("");
  };

  const handleSignIn = () => {
    loginWithRedirect();
  };

  const handleSocialLogin = (connection) => {
    loginWithRedirect({
      authorizationParams: { connection },
    });
  };

  if (step === "success") {
    return (
      <main className="register-page">
        <div className="success-container">
          <svg
            className="success-envelope"
            width="80"
            height="80"
            viewBox="0 0 24 24"
            fill="none"
          >
            <rect x="2" y="4" width="20" height="16" rx="2" fill="#e8e8e8" />
            <path
              d="M2 4l10 8 10-8"
              stroke="#d0d0d0"
              strokeWidth="1.5"
              fill="none"
            />
          </svg>
          <h1 className="success-title">We Sent you an Email</h1>
          <p className="success-text">
            Check your email address {email}. It contains a link to complete
            your registration. This link will be active for 72 hours. Didn't
            receive the email? Check your spam folder in case the email was
            incorrectly identified.
          </p>
          {/* <button className="success-resend-link" onClick={() => {}}>
            Resend Activation Email <span className="chevron-right">›</span>
          </button>*/}
        </div>
      </main>
    );
  }

  if (step === "profile") {
    return (
      <main className="register-page">
        <div className="register-header">
          <h1 className="register-title">Create Account</h1>
          <p className="register-subtitle">
            Create a free account with My Toyota to receive offers from your
            preferred dealer, stay connected to your vehicle, and access all the
            tools for your Toyota in one place.
          </p>
        </div>

        <div className="register-card">
          <div className="profile-form">
            <div className="form-field full-width">
              <label className="floating-label">Email *</label>
              <input
                type="email"
                value={email}
                readOnly
                className="form-input filled"
              />
            </div>

            <div className="form-row">
              <div className="form-field">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Password *"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="form-input"
                />
                <button
                  type="button"
                  className="show-toggle"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                  {showPassword ? "Hide" : "Show"}
                </button>
              </div>
              <div className="form-field">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  placeholder="Confirm Password *"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="form-input"
                />
                <button
                  type="button"
                  className="show-toggle"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                  {showConfirmPassword ? "Hide" : "Show"}
                </button>
              </div>
            </div>

            <div className="password-requirements">
              <p className="requirements-title">
                Your password must meet the following requirements:
              </p>
              <ul className="requirements-list">
                {passwordRequirements.map((req, i) => (
                  <li
                    key={i}
                    className={`requirement ${req.met ? "met" : "unmet"}`}
                  >
                    {req.met ? (
                      <svg
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                      >
                        <circle cx="12" cy="12" r="10" fill="#2e7d32" />
                        <path
                          d="M9 12l2 2 4-4"
                          stroke="#fff"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    ) : (
                      <svg
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                      >
                        <circle cx="12" cy="12" r="10" fill="#d32f2f" />
                        <line
                          x1="12"
                          y1="8"
                          x2="12"
                          y2="13"
                          stroke="#fff"
                          strokeWidth="2"
                          strokeLinecap="round"
                        />
                        <circle cx="12" cy="16" r="1" fill="#fff" />
                      </svg>
                    )}
                    <span>{req.label}</span>
                  </li>
                ))}
              </ul>
            </div>

            <hr className="form-divider" />

            <div className="form-row">
              <div className="form-field">
                <input
                  type="text"
                  placeholder="First Name *"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="form-input"
                />
              </div>
              <div className="form-field">
                <input
                  type="text"
                  placeholder="Last Name *"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="form-input"
                />
              </div>
            </div>

            <div className="form-field full-width">
              <div className="phone-input-wrapper">
                <span className="phone-prefix">+1</span>
                <input
                  type="tel"
                  placeholder="Phone Number (10 digits) *"
                  value={phoneNumber}
                  onChange={(e) => {
                    const digits = e.target.value
                      .replace(/\D/g, "")
                      .slice(0, 10);
                    setPhoneNumber(digits);
                  }}
                  className="form-input phone-input"
                />
              </div>
              <p className="field-hint">Phone Number must be text enabled.</p>
            </div>

            <p className="required-note">
              <span className="asterisk">*</span> Required Fields
            </p>
          </div>
        </div>

        <div className="form-actions">
          <button className="cancel-btn" onClick={handleCancel}>
            Cancel
          </button>
          <button
            className="submit-btn"
            disabled={!isFormComplete}
            onClick={handleCreateAccount}
          >
            Create Account
          </button>
        </div>

        <button className="already-account-link" onClick={handleSignIn}>
          Already have an account? <span className="chevron-right">›</span>
        </button>
      </main>
    );
  }

  return (
    <main className="register-page">
      <div className="register-header">
        <h1 className="register-title">Create Account</h1>
        <p className="register-subtitle">
          Create a free account with My Toyota to receive offers from your
          preferred dealer, stay connected to your vehicle, and access all the
          tools for your Toyota in one place.
        </p>
      </div>

      <div className="register-card">
        <div className="register-card-inner">
          <div className="register-email-section">
            <h2 className="section-title">Use your Email Address</h2>
            <div
              className={`email-input-wrapper ${showError || showAliasError ? "error" : ""}`}
            >
              <input
                type="email"
                placeholder="Email Address *"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setTouched(true);
                }}
                onBlur={() => setTouched(true)}
                className={`email-input ${showError || showAliasError ? "input-error" : ""}`}
              />
            </div>
            {showError && (
              <p className="error-message">Please enter a correct email.</p>
            )}
            {showAliasError && <p className="error-message">Invalid Email</p>}
            <button
              className="create-account-btn"
              disabled={!isEmailButtonEnabled}
              onClick={handleEmailSubmit}
            >
              Create Account
            </button>
            <button className="sign-in-link" onClick={handleSignIn}>
              Sign In Instead <span className="chevron-right">›</span>
            </button>
          </div>

          <div className="register-divider">
            <span>OR</span>
          </div>

          <div className="register-sso-section">
            <h2 className="section-title">Continue with Single Sign-On</h2>
            <div className="sso-buttons">
              <button
                className="sso-btn"
                onClick={() => handleSocialLogin("apple")}
              >
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
                </svg>
                <span>Continue with Apple</span>
              </button>
              <button
                className="sso-btn"
                onClick={() => handleSocialLogin("google-oauth2")}
              >
                <svg width="20" height="20" viewBox="0 0 24 24">
                  <path
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    fill="#4285F4"
                  />
                  <path
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    fill="#34A853"
                  />
                  <path
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    fill="#FBBC05"
                  />
                  <path
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    fill="#EA4335"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>
              <button
                className="sso-btn"
                onClick={() => handleSocialLogin("facebook")}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M12 2C6.477 2 2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.879V14.89h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.989C18.343 21.129 22 16.99 22 12c0-5.523-4.477-10-10-10z"
                    fill="#0082FB"
                  />
                </svg>
                <span>Continue with Meta</span>
              </button>
            </div>
          </div>
        </div>

        <div className="register-card-footer">
          <p>
            You can use your My Lexus or My Toyota account information to log
            in.
          </p>
          <div className="footer-links">
            {/* <a href="#">
              Activate Account <span className="chevron-right">›</span>
            </a>*/}
            <a href="#">
              Support <span className="chevron-right">›</span>
            </a>
          </div>
        </div>
      </div>

      <div className="business-card">
        <h2 className="business-title">
          Creating an account for your business?
        </h2>
        <p className="business-subtitle">
          It looks like you don't have a My Toyota account. Complete
          registration below to create one.
        </p>
        <button className="business-btn">Create a Business Account</button>
      </div>
    </main>
  );
}

export default Register;
