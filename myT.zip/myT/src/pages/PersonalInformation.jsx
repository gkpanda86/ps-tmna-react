import { useState, useEffect } from "react";
import { useAuth0 } from "@auth0/auth0-react";
import "./PersonalInformation.css";

const US_STATES = [
  "AL",
  "AK",
  "AZ",
  "AR",
  "CA",
  "CO",
  "CT",
  "DE",
  "FL",
  "GA",
  "HI",
  "ID",
  "IL",
  "IN",
  "IA",
  "KS",
  "KY",
  "LA",
  "ME",
  "MD",
  "MA",
  "MI",
  "MN",
  "MS",
  "MO",
  "MT",
  "NE",
  "NV",
  "NH",
  "NJ",
  "NM",
  "NY",
  "NC",
  "ND",
  "OH",
  "OK",
  "OR",
  "PA",
  "RI",
  "SC",
  "SD",
  "TN",
  "TX",
  "UT",
  "VT",
  "VA",
  "WA",
  "WV",
  "WI",
  "WY",
];

function maskLastName(name) {
  if (!name) return "";
  return name.charAt(0) + "*".repeat(Math.max(name.length - 1, 5));
}

function maskPhone(phone) {
  if (!phone) return "";
  const digits = phone.replace(/\D/g, "");
  if (digits.length >= 4) {
    const last4 = digits.slice(-4);
    return `(***) ***-${last4}`;
  }
  return phone;
}

function maskEmail(email) {
  if (!email) return "";
  const [local, domain] = email.split("@");
  if (!domain) return email;
  const visibleChars = Math.min(3, local.length);
  return (
    local.slice(0, visibleChars) +
    "*".repeat(Math.max(local.length - visibleChars, 5)) +
    "@" +
    domain
  );
}

function PersonalInformation() {
  const { user, getIdTokenClaims, loginWithRedirect } = useAuth0();
  const [profileData, setProfileData] = useState(null);
  const [editData, setEditData] = useState(null);
  const [hasMfa, setHasMfa] = useState(false);
  const [activeTab, setActiveTab] = useState(() => {
    const savedTab = sessionStorage.getItem("myt_return_tab");
    if (savedTab) {
      sessionStorage.removeItem("myt_return_tab");
      return savedTab;
    }
    return "personal";
  });

  const [successMessage, setSuccessMessage] = useState("");

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const passwordRequirements = [
    {
      label: "Use 8 - 16 characters",
      met: newPassword.length >= 8 && newPassword.length <= 16,
    },
    {
      label: "Use uppercase and lowercase letters",
      met: /[a-z]/.test(newPassword) && /[A-Z]/.test(newPassword),
    },
    { label: "Use a number (0-9)", met: /\d/.test(newPassword) },
    {
      label: "Use a special character (@ # & % ! ~)",
      met: /[@#&%!~]/.test(newPassword),
    },
    {
      label: "Passwords match",
      met:
        newPassword.length > 0 &&
        confirmPassword.length > 0 &&
        newPassword === confirmPassword,
    },
  ];

  const allPasswordRequirementsMet =
    passwordRequirements.every((r) => r.met) && currentPassword.length > 0;

  const handleSavePassword = async () => {
    const payload = {
      id: user?.sub,
      oldPassword: currentPassword,
      newPassword,
    };

    try {
      const response = await fetch(
        "https://demo-tmna-pscollab.workflows.oktapreview.com/api/flo/3f88f21fc317b076c67f67bf36c916b8/invoke?clientToken=741ebcb2c67cd95ef3c38191830279385099064095829764155a391008f12713",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        },
      );
      if (response.ok) {
        setSuccessMessage("Your password has been changed successfully.");
      }
    } catch (err) {
      console.error("Password change failed:", err);
    }
  };

  useEffect(() => {
    async function checkMfaAndFetchProfile() {
      const email = user?.email;
      if (!email) return;

      const claims = await getIdTokenClaims();
      if (claims?.amr && claims.amr.length > 0) {
        setHasMfa(true);
      }

      try {
        const response = await fetch(
          "https://demo-tmna-pscollab.workflows.oktapreview.com/api/flo/8463aa30b3310266fba866bedbc6940f/invoke?clientToken=de01a10883169df7f7a0ae3c6b0cf5ba647e8a3fa89fb20a6d7961acce282ae5",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email }),
          },
        );
        const data = await response.json();

        if (data.statusCode === 200) {
          const phone = (data.phone_number || "").replace(/\D/g, "");
          const profile = {
            firstName: data.firstName || "",
            lastName: data.lastName || "",
            address1: "",
            address2: "",
            city: "",
            state: "",
            zip: "",
            phone: phone.startsWith("1") ? phone.slice(1) : phone,
            email: data.email || "",
          };
          setProfileData(profile);
          setEditData({ ...profile });
        }
      } catch (err) {
        console.error("Failed to fetch profile:", err);
      }
    }

    checkMfaAndFetchProfile();
  }, [user, getIdTokenClaims]);

  const handleEditInformation = () => {
    loginWithRedirect({
      authorizationParams: {
        acr_values:
          "http://schemas.openid.net/pape/policies/2007/06/multi-factor",
        redirect_uri: `${window.location.origin}/my-dashboard/personal-information`,
      },
    });
  };

  const handleFieldChange = (field, value) => {
    setEditData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSaveProfile = async () => {
    const phone = editData.phone.replace(/\D/g, "");
    const formattedPhone = phone.startsWith("1") ? `+${phone}` : `+1${phone}`;

    const payload = {
      email: editData.email,
      firstName: editData.firstName,
      lastName: editData.lastName,
      id: user?.sub,
      phone: formattedPhone,
    };

    try {
      const response = await fetch(
        "https://demo-tmna-pscollab.workflows.oktapreview.com/api/flo/d82a9e62dfbfab4ca157dbcde79234df/invoke?clientToken=7f987e342c30b245293d8caf7e98d25b297d07ba13a9d8afebac7c158d0cc453",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        },
      );
      if (response.ok) {
        setSuccessMessage("Your profile has been updated successfully.");
      }
    } catch (err) {
      console.error("Profile update failed:", err);
    }
  };

  const handleUpdatePassword = () => {
    sessionStorage.setItem("myt_return_tab", "password");
    loginWithRedirect({
      authorizationParams: {
        acr_values:
          "http://schemas.openid.net/pape/policies/2007/06/multi-factor",
        redirect_uri: `${window.location.origin}/my-dashboard/personal-information`,
      },
    });
  };

  if (!profileData) {
    return <div className="pi-loading">Loading...</div>;
  }

  const tabs = [
    { id: "personal", label: "Personal Information" },
    { id: "password", label: "Password Settings" },
    { id: "communication", label: "Communication Preferences" },
  ];

  return (
    <main className="pi-page">
      <div className="pi-hero">
        <h1 className="pi-hero-title">My Account</h1>
        <p className="pi-hero-subtitle">
          Update your account information and manage communication preferences.
        </p>
      </div>

      <div className="pi-content">
        <nav className="pi-tabs">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`pi-tab ${activeTab === tab.id ? "active" : ""}`}
              onClick={() => { setActiveTab(tab.id); setSuccessMessage(""); }}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        {activeTab === "personal" && (
          <>
            <h2 className="pi-section-title">Personal Information</h2>

            <div className="pi-form-card">
              <div className="pi-form">
                <div className="pi-form-row">
                  <div className="pi-field">
                    <label className="pi-label">First Name *</label>
                    <input
                      type="text"
                      className="pi-input"
                      value={
                        hasMfa ? editData.firstName : profileData.firstName
                      }
                      onChange={(e) =>
                        handleFieldChange("firstName", e.target.value)
                      }
                      disabled={!hasMfa}
                    />
                  </div>
                  <div className="pi-field">
                    <label className="pi-label">Last Name *</label>
                    <input
                      type="text"
                      className="pi-input"
                      value={
                        hasMfa
                          ? editData.lastName
                          : maskLastName(profileData.lastName)
                      }
                      onChange={(e) =>
                        handleFieldChange("lastName", e.target.value)
                      }
                      disabled={!hasMfa}
                    />
                  </div>
                </div>

                <div className="pi-field full">
                  <input
                    type="text"
                    className="pi-input"
                    placeholder="Address Line 1"
                    value={hasMfa ? editData.address1 : profileData.address1}
                    onChange={(e) =>
                      handleFieldChange("address1", e.target.value)
                    }
                    disabled={!hasMfa}
                  />
                </div>

                <div className="pi-field full">
                  <input
                    type="text"
                    className="pi-input"
                    placeholder="Address Line 2"
                    value={hasMfa ? editData.address2 : profileData.address2}
                    onChange={(e) =>
                      handleFieldChange("address2", e.target.value)
                    }
                    disabled={!hasMfa}
                  />
                </div>

                <div className="pi-form-row three-col">
                  <div className="pi-field city">
                    <input
                      type="text"
                      className="pi-input"
                      placeholder="City"
                      value={hasMfa ? editData.city : profileData.city}
                      onChange={(e) =>
                        handleFieldChange("city", e.target.value)
                      }
                      disabled={!hasMfa}
                    />
                  </div>
                  <div className="pi-field state">
                    <select
                      className="pi-input pi-select"
                      value={hasMfa ? editData.state : profileData.state}
                      onChange={(e) =>
                        handleFieldChange("state", e.target.value)
                      }
                      disabled={!hasMfa}
                    >
                      <option value="">State</option>
                      {US_STATES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="pi-field zip">
                    <input
                      type="text"
                      className="pi-input"
                      placeholder="Zip"
                      value={hasMfa ? editData.zip : profileData.zip}
                      onChange={(e) => handleFieldChange("zip", e.target.value)}
                      disabled={!hasMfa}
                    />
                  </div>
                </div>

                <div className="pi-form-row">
                  <div className="pi-field">
                    <label className="pi-label">Phone Number *</label>
                    <input
                      type="text"
                      className="pi-input"
                      value={
                        hasMfa ? editData.phone : maskPhone(profileData.phone)
                      }
                      onChange={(e) =>
                        handleFieldChange("phone", e.target.value)
                      }
                      disabled={!hasMfa}
                    />
                  </div>
                  <div className="pi-field">
                    <input
                      type="text"
                      className="pi-input"
                      placeholder="Phone Number(Alt)"
                      value=""
                      disabled={!hasMfa}
                    />
                  </div>
                </div>

                <div className="pi-field full">
                  <label className="pi-label">Email Address *</label>
                  <input
                    type="text"
                    className="pi-input"
                    value={
                      hasMfa ? editData.email : maskEmail(profileData.email)
                    }
                    onChange={(e) => handleFieldChange("email", e.target.value)}
                    disabled={!hasMfa}
                  />
                </div>

                <p className="pi-required-note">
                  <span className="asterisk">*</span> Required fields
                </p>
              </div>
            </div>

            <p className="pi-privacy-note">
              Protecting your privacy is important to us.{" "}
              <a href="#" className="pi-link">
                Click here
              </a>{" "}
              for a step-by-step guide on removing all personal data from your
              vehicle.
            </p>

            {successMessage && activeTab === "personal" && (
              <p className="pi-success-message">{successMessage}</p>
            )}

            <div className="pi-actions">
              {hasMfa ? (
                <button className="pi-edit-btn" onClick={handleSaveProfile}>
                  Save
                </button>
              ) : (
                <button className="pi-edit-btn" onClick={handleEditInformation}>
                  Edit Information
                </button>
              )}
            </div>
          </>
        )}

        {activeTab === "password" && (
          <>
            <h2 className="pi-section-title">Update Password</h2>

            {!hasMfa && (
              <p className="pw-no-mfa-text">
                Click on update password button to change your password
              </p>
            )}

            {hasMfa && (
              <>
            <p className="pw-subtitle">
              Your new password cannot be one of your last four passwords used,
              and must meet the additional requirements listed below
            </p>

            <div className="pw-card">
              <div className="pw-card-inner">
                <div className="pw-fields">
                  <div className="pw-field">
                    <input
                      type={showCurrentPassword ? "text" : "password"}
                      placeholder="Current Password *"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      className="pi-input"
                      disabled={!hasMfa}
                    />
                    {hasMfa && (
                      <button
                        type="button"
                        className="pw-show-toggle"
                        onClick={() =>
                          setShowCurrentPassword(!showCurrentPassword)
                        }
                      >
                        <svg
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                          <circle cx="12" cy="12" r="3" />
                        </svg>
                        {showCurrentPassword ? "Hide" : "Show"}
                      </button>
                    )}
                  </div>

                  <p className="pw-forgot-link">Forgot Password?</p>

                  <div className="pw-field">
                    <input
                      type={showNewPassword ? "text" : "password"}
                      placeholder="New Password *"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="pi-input"
                      disabled={!hasMfa}
                    />
                    {hasMfa && (
                      <button
                        type="button"
                        className="pw-show-toggle"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                      >
                        <svg
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                          <circle cx="12" cy="12" r="3" />
                        </svg>
                        {showNewPassword ? "Hide" : "Show"}
                      </button>
                    )}
                  </div>

                  <div className="pw-field">
                    <input
                      type={showConfirmPassword ? "text" : "password"}
                      placeholder="Confirm Password *"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="pi-input"
                      disabled={!hasMfa}
                    />
                    {hasMfa && (
                      <button
                        type="button"
                        className="pw-show-toggle"
                        onClick={() =>
                          setShowConfirmPassword(!showConfirmPassword)
                        }
                      >
                        <svg
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                          <circle cx="12" cy="12" r="3" />
                        </svg>
                        {showConfirmPassword ? "Hide" : "Show"}
                      </button>
                    )}
                  </div>
                </div>

                <div className="pw-requirements">
                  <ul className="pw-requirements-list">
                    {passwordRequirements.map((req, i) => (
                      <li
                        key={i}
                        className={`pw-requirement ${req.met ? "met" : "unmet"}`}
                      >
                        {req.met ? (
                          <svg
                            width="20"
                            height="20"
                            viewBox="0 0 24 24"
                            fill="none"
                          >
                            <circle cx="12" cy="12" r="10" fill="#2e7d32" />
                            <path
                              d="M9 12l2 2 4-4"
                              stroke="#fff"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        ) : (
                          <svg
                            width="20"
                            height="20"
                            viewBox="0 0 24 24"
                            fill="none"
                          >
                            <circle cx="12" cy="12" r="10" fill="#d32f2f" />
                            <line
                              x1="12"
                              y1="8"
                              x2="12"
                              y2="13"
                              stroke="#fff"
                              strokeWidth="2"
                              strokeLinecap="round"
                            />
                            <circle cx="12" cy="16" r="1" fill="#fff" />
                          </svg>
                        )}
                        <span>{req.label}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {successMessage && activeTab === "password" && (
              <p className="pi-success-message">{successMessage}</p>
            )}

            <div className="pi-actions">
              <button
                className="pw-save-btn"
                disabled={!allPasswordRequirementsMet}
                onClick={handleSavePassword}
              >
                Save Changes
              </button>
            </div>
              </>
            )}

            {!hasMfa && (
              <div className="pi-actions">
                <button className="pi-edit-btn" onClick={handleUpdatePassword}>
                  Update Password
                </button>
              </div>
            )}
          </>
        )}

        {activeTab === "communication" && (
          <>
            <h2 className="pi-section-title">Communication Preferences</h2>
            <div className="cp-card">
              <p className="cp-text">
                Manage your notifications and communication preferences below
              </p>
              <button className="cp-btn">Update Preferences</button>
            </div>
          </>
        )}
      </div>
    </main>
  );
}

export default PersonalInformation;
