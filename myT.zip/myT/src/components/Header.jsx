import { useState, useRef, useEffect } from 'react'
import AccountDropdown from './AccountDropdown'
import './Header.css'

function Header() {
  const [accountOpen, setAccountOpen] = useState(false)
  const dropdownRef = useRef(null)
  const buttonRef = useRef(null)

  useEffect(() => {
    function handleClickOutside(event) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target) &&
        buttonRef.current &&
        !buttonRef.current.contains(event.target)
      ) {
        setAccountOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <header className="header">
      <div className="header-inner">
        <div className="header-left">
          <a href="/" className="header-logo" aria-label="Toyota Home">
            <svg viewBox="0 0 40 40" width="40" height="40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect width="40" height="40" rx="4" fill="#EB0A1E"/>
              <ellipse cx="20" cy="20" rx="12" ry="8.5" stroke="white" strokeWidth="1.5" fill="none"/>
              <ellipse cx="20" cy="20" rx="5.5" ry="8.5" stroke="white" strokeWidth="1.5" fill="none"/>
              <line x1="8" y1="20" x2="32" y2="20" stroke="white" strokeWidth="1.5"/>
            </svg>
          </a>
          <nav className="header-nav">
            <a href="#" className="nav-link">Vehicles</a>
            <a href="#" className="nav-link">Shop</a>
            <a href="#" className="nav-link">Support & Service</a>
          </nav>
        </div>
        <div className="header-right">
          <button
            ref={buttonRef}
            className="account-button"
            onClick={() => setAccountOpen(!accountOpen)}
            aria-expanded={accountOpen}
            aria-haspopup="true"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="8" r="4"/>
              <path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"/>
            </svg>
            <span>Account</span>
          </button>
          {accountOpen && (
            <div ref={dropdownRef}>
              <AccountDropdown onClose={() => setAccountOpen(false)} />
            </div>
          )}
        </div>
      </div>
    </header>
  )
}

export default Header
