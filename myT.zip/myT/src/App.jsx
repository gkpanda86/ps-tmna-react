import { Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Register from './pages/Register'
import PersonalInformation from './pages/PersonalInformation'
import './App.css'

function App() {
  return (
    <div className="app">
      <Header />
      <Routes>
        <Route path="/" element={
          <main className="main-content">
            <h1>Welcome to Toyota</h1>
            <p>Explore vehicles, shop, and manage your Toyota experience.</p>
          </main>
        } />
        <Route path="/owners/register" element={<Register />} />
        <Route path="/my-dashboard/personal-information" element={<PersonalInformation />} />
      </Routes>
    </div>
  )
}

export default App
