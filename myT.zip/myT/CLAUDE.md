# myT - Toyota.com Clone

## Project Overview

React web app mimicking toyota.com, built with Vite and Auth0 for OIDC authentication.

## Tech Stack

- React 18 + Vite
- React Router (client-side routing)
- @auth0/auth0-react (OIDC authentication)
- CSS (no framework, component-scoped `.css` files)

## Auth0 Configuration

- Config lives in `.env` (VITE_AUTH0_DOMAIN, VITE_AUTH0_CLIENT_ID)
- Auth0Provider wraps the app in `src/main.jsx`
- Domain: `pscollab-tmna.oktademo.cloud`

## Running the App

```bash
nvm use --lts
npm install
npm run dev
```

Dev server runs at http://localhost:5173

## Project Structure

```
src/
├── main.jsx                        # Entry: Auth0Provider + BrowserRouter
├── App.jsx                         # Route definitions
├── App.css / index.css             # Global styles
├── components/
│   ├── Header.jsx/css              # Sticky header + nav
│   ├── AccountDropdown.jsx/css     # Account dropdown (logged in/out)
└── pages/
    ├── Register.jsx/css            # /owners/register (2-step registration)
    ├── PersonalInformation.jsx/css # /my-dashboard/personal-information (3 tabs)
```

## Routes

| Path | Component | Auth Required |
|------|-----------|---------------|
| `/` | Landing page (inline) | No |
| `/owners/register` | Register | No |
| `/my-dashboard/personal-information` | PersonalInformation | Yes (logged in) |

## Fake API Endpoints (placeholders)

These endpoints don't exist yet. They log to console or fail silently. Replace with real APIs later.

| Endpoint | Method | Body | Purpose |
|----------|--------|------|---------|
| `/api/register` | POST | `{ email, password, firstName, lastName, phoneNumber }` | Account registration |
| `/api/profile` | POST | `{ sub }` | Fetch user profile |
| `/api/change-password` | POST | `{ sub, currentPassword, newPassword }` | Update password |

## Conventions

- Component-scoped CSS files (e.g., `Header.css` for `Header.jsx`)
- No CSS framework — plain CSS with BEM-ish class naming prefixed by page/component
- SVG icons inline (no icon library)
- Auth0 `loginWithRedirect()` for all login/signup flows
- Masking functions for PII (last name, phone, email) in PersonalInformation page

## Important Notes

- Always run `nvm use --lts` before npm commands (project uses Node v24 LTS)
- The `.env` file contains real Auth0 tenant credentials — do not commit to public repos
- Profile data on the Personal Information page is hardcoded; will be replaced with real API
